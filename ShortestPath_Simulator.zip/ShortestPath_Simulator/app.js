/**
 * PathPilot 2.0 — app.js
 * Interactive Shortest Path Algorithm Simulator
 * All computation is local to the browser. No build step required.
 */

'use strict';

/* ================================================================
   SECTION 1: CONSTANTS & ALGORITHM METADATA
================================================================ */

const INFINITY = Infinity;
const INF_DISPLAY = '∞';
const NODE_RADIUS = 20;
const MAX_NODES = 20;

const ALGO_META = {
  dijkstra: {
    name: "Dijkstra's Algorithm",
    description: "Finds shortest paths from a single source in a weighted graph with non-negative edge weights. Uses a greedy selection strategy — always processing the nearest unvisited vertex.",
    timeComplexity: "O(V² + E)",
    spaceComplexity: "O(V)",
    useCases: ["GPS routing", "Network routing protocols", "Games (pathfinding)"],
    limitations: ["Fails with negative edge weights", "O(V²) for dense graphs without priority queue"],
    requiresWeighted: false,
    requiresNonNegative: true,
    requiresDirected: false,
    requiresSource: true,
    requiresTarget: false,
    allowsNegative: false,
    requiresDAG: false,
    requires01: false,
  },
  'bellman-ford': {
    name: "Bellman-Ford Algorithm",
    description: "Finds shortest paths from a single source, supporting negative edge weights. Detects negative cycles reachable from the source. Runs V-1 relaxation passes over all edges.",
    timeComplexity: "O(V × E)",
    spaceComplexity: "O(V)",
    useCases: ["Negative-weight edges", "Detecting negative cycles", "Distributed routing (RIP)"],
    limitations: ["Slower than Dijkstra for non-negative graphs", "Cannot give meaningful results if negative cycle is reachable"],
    requiresWeighted: false,
    requiresNonNegative: false,
    requiresDirected: false,
    requiresSource: true,
    requiresTarget: false,
    allowsNegative: true,
    requiresDAG: false,
    requires01: false,
  },
  bfs: {
    name: "Breadth-First Search (BFS)",
    description: "Finds the path with the fewest edges (hops) in an unweighted graph. Edge weights are ignored — BFS optimizes hop count, not total weight.",
    timeComplexity: "O(V + E)",
    spaceComplexity: "O(V)",
    useCases: ["Unweighted shortest path", "Social network degrees", "Puzzle solving", "Peer-to-peer networks"],
    limitations: ["Ignores edge weights", "Not suitable when path cost matters"],
    requiresWeighted: false,
    requiresNonNegative: false,
    requiresDirected: false,
    requiresSource: true,
    requiresTarget: false,
    allowsNegative: true,
    requiresDAG: false,
    requires01: false,
  },
  'floyd-warshall': {
    name: "Floyd-Warshall Algorithm",
    description: "Computes all-pairs shortest paths using dynamic programming. Considers every vertex as an intermediate node. Detects negative cycles via negative diagonal entries.",
    timeComplexity: "O(V³)",
    spaceComplexity: "O(V²)",
    useCases: ["All-pairs distances", "Transitive closure", "Dense graphs"],
    limitations: ["Cubic time — impractical for large graphs", "Negative cycles invalidate results for affected pairs"],
    requiresWeighted: false,
    requiresNonNegative: false,
    requiresDirected: false,
    requiresSource: false,
    requiresTarget: false,
    allowsNegative: true,
    requiresDAG: false,
    requires01: false,
  },
  astar: {
    name: "A* Search",
    description: "Heuristic-guided shortest path search. Uses f(n) = g(n) + h(n) to prioritize vertices likely to be on the shortest path. With h=0, equivalent to Dijkstra.",
    timeComplexity: "O((V+E) log V) with admissible heuristic (worst-case exponential in general)",
    spaceComplexity: "O(V)",
    useCases: ["Games and robotics", "Map navigation", "Planning problems with heuristic estimates"],
    limitations: ["Heuristic must be admissible for guaranteed optimality", "Performance depends on heuristic quality"],
    requiresWeighted: false,
    requiresNonNegative: true,
    requiresDirected: false,
    requiresSource: true,
    requiresTarget: true,
    allowsNegative: false,
    requiresDAG: false,
    requires01: false,
  },
  dag: {
    name: "DAG Shortest Path",
    description: "Finds shortest paths from a source in a Directed Acyclic Graph using topological ordering. Supports negative edges. O(V+E) — optimal for DAGs.",
    timeComplexity: "O(V + E)",
    spaceComplexity: "O(V)",
    useCases: ["Project scheduling (PERT/CPM)", "Dependency resolution", "DAG-structured problems with negative weights"],
    limitations: ["Requires directed acyclic graph", "Detects and rejects graphs with cycles"],
    requiresWeighted: false,
    requiresNonNegative: false,
    requiresDirected: true,
    requiresSource: true,
    requiresTarget: false,
    allowsNegative: true,
    requiresDAG: true,
    requires01: false,
  },
  '01bfs': {
    name: "0-1 BFS",
    description: "Finds shortest paths when every edge weight is exactly 0 or 1. Uses a double-ended queue (deque): 0-weight neighbors go to front, 1-weight neighbors to back.",
    timeComplexity: "O(V + E)",
    spaceComplexity: "O(V)",
    useCases: ["Binary-weighted graphs", "Graphs with free/costly transitions", "Modified BFS with edge distinctions"],
    limitations: ["Requires all weights to be 0 or 1", "Does not generalize to arbitrary weights"],
    requiresWeighted: true,
    requiresNonNegative: false,
    requiresDirected: false,
    requiresSource: true,
    requiresTarget: false,
    allowsNegative: false,
    requiresDAG: false,
    requires01: true,
  }
};

const PSEUDOCODE = {
  dijkstra: [
    "DIJKSTRA(G, source):",
    "  dist[source] ← 0",
    "  dist[v] ← ∞  for all v ≠ source",
    "  prev[v] ← nil  for all v",
    "  Q ← all vertices (unvisited set)",
    "  while Q is not empty:",
    "    u ← vertex in Q with min dist[u]",
    "    remove u from Q  (mark as visited)",
    "    for each neighbor v of u:",
    "      alt ← dist[u] + weight(u, v)",
    "      if alt < dist[v]:",
    "        dist[v] ← alt",
    "        prev[v] ← u",
    "  return dist, prev",
  ],
  'bellman-ford': [
    "BELLMAN-FORD(G, source):",
    "  dist[source] ← 0",
    "  dist[v] ← ∞  for all v ≠ source",
    "  prev[v] ← nil  for all v",
    "  for pass ← 1 to |V| - 1:",
    "    changed ← false",
    "    for each edge (u, v, w) in G:",
    "      if dist[u] ≠ ∞ and dist[u] + w < dist[v]:",
    "        dist[v] ← dist[u] + w",
    "        prev[v] ← u",
    "        changed ← true",
    "    if not changed: break  (early exit)",
    "  // Negative cycle check:",
    "  for each edge (u, v, w) in G:",
    "    if dist[u] ≠ ∞ and dist[u] + w < dist[v]:",
    "      report NEGATIVE CYCLE reachable",
    "  return dist, prev",
  ],
  bfs: [
    "BFS(G, source):",
    "  dist[source] ← 0",
    "  dist[v] ← ∞  for all v ≠ source",
    "  prev[v] ← nil  for all v",
    "  discovered[source] ← true",
    "  Q ← queue containing source",
    "  while Q is not empty:",
    "    u ← dequeue(Q)",
    "    for each neighbor v of u:",
    "      if not discovered[v]:",
    "        discovered[v] ← true",
    "        dist[v] ← dist[u] + 1",
    "        prev[v] ← u",
    "        enqueue(Q, v)",
    "  return dist, prev",
  ],
  'floyd-warshall': [
    "FLOYD-WARSHALL(G):",
    "  D[i][j] ← weight(i,j) if edge exists",
    "  D[i][i] ← 0  for all i",
    "  D[i][j] ← ∞  for all missing edges",
    "  next[i][j] ← j  if edge (i,j) exists",
    "  for k ← 1 to |V|:",
    "    for i ← 1 to |V|:",
    "      for j ← 1 to |V|:",
    "        if D[i][k] + D[k][j] < D[i][j]:",
    "          D[i][j] ← D[i][k] + D[k][j]",
    "          next[i][j] ← next[i][k]",
    "  // Negative cycle detection:",
    "  if D[i][i] < 0 for any i: CYCLE DETECTED",
    "  return D, next",
  ],
  astar: [
    "A-STAR(G, source, target, h):",
    "  g[source] ← 0;  g[v] ← ∞ for v ≠ source",
    "  f[source] ← h(source)",
    "  prev[v] ← nil  for all v",
    "  open ← priority queue with source",
    "  closed ← empty set",
    "  while open is not empty:",
    "    u ← node in open with min f[u]",
    "    if u = target: reconstruct path, return",
    "    remove u from open; add u to closed",
    "    for each neighbor v of u:",
    "      tentative_g ← g[u] + weight(u, v)",
    "      if v in closed and tentative_g >= g[v]: skip",
    "      if tentative_g < g[v]:",
    "        g[v] ← tentative_g",
    "        f[v] ← g[v] + h(v)",
    "        prev[v] ← u",
    "        add v to open (or update)",
    "  return NO PATH",
  ],
  dag: [
    "DAG-SHORTEST(G, source):",
    "  order ← TOPOLOGICAL-SORT(G)",
    "  if |order| ≠ |V|: ERROR — graph has cycle",
    "  dist[source] ← 0",
    "  dist[v] ← ∞  for all v ≠ source",
    "  prev[v] ← nil  for all v",
    "  for each u in topological order:",
    "    if dist[u] = ∞: skip (unreachable)",
    "    for each edge (u, v, w):",
    "      if dist[u] + w < dist[v]:",
    "        dist[v] ← dist[u] + w",
    "        prev[v] ← u",
    "  return dist, prev",
  ],
  '01bfs': [
    "01-BFS(G, source):",
    "  dist[source] ← 0",
    "  dist[v] ← ∞  for all v ≠ source",
    "  prev[v] ← nil  for all v",
    "  deque ← [source]",
    "  while deque is not empty:",
    "    u ← pop_front(deque)",
    "    if dist[u] already finalized: skip",
    "    for each edge (u, v, w) where w ∈ {0, 1}:",
    "      alt ← dist[u] + w",
    "      if alt < dist[v]:",
    "        dist[v] ← alt",
    "        prev[v] ← u",
    "        if w = 0: push_front(deque, v)",
    "        if w = 1: push_back(deque, v)",
    "  return dist, prev",
  ],
};

/* ================================================================
   SECTION 2: GRAPH DATA MODEL
================================================================ */

let graph = {
  directed: false,
  nodes: [],       // { id, label, x, y }
  edges: [],       // { id, from, to, weight }
  source: null,
  target: null,
};

let nextNodeId = 1;
let nextEdgeId = 1;

function cloneGraph(g) {
  return JSON.parse(JSON.stringify(g));
}

function getNode(id) { return graph.nodes.find(n => n.id === id) || null; }
function getEdge(id) { return graph.edges.find(e => e.id === id) || null; }

function getNodeLabel(id) {
  const n = getNode(id);
  return n ? n.label : String(id);
}

function addNode(x, y) {
  if (graph.nodes.length >= MAX_NODES) {
    showValidation(`Maximum ${MAX_NODES} nodes allowed for interactive demo.`, 'warning');
    return null;
  }
  const label = nextFreeLabel();
  const node = { id: nextNodeId++, label, x, y };
  graph.nodes.push(node);
  invalidateResults();
  updateAll();
  return node;
}

function generateLabel(idx) {
  // A, B, C, ... Z, A1, B1, ...
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const cycle = Math.floor(idx / 26);
  const letter = letters[idx % 26];
  return cycle === 0 ? letter : letter + cycle;
}

function nextFreeLabel() {
  const used = new Set(graph.nodes.map(n => n.label));
  for (let i = 0; i < 1000; i++) { const l = generateLabel(i); if (!used.has(l)) return l; }
  return 'N' + nextNodeId;
}

function removeNode(id) {
  graph.nodes = graph.nodes.filter(n => n.id !== id);
  graph.edges = graph.edges.filter(e => e.from !== id && e.to !== id);
  if (graph.source === id) graph.source = null;
  if (graph.target === id) graph.target = null;
  invalidateResults();
  updateAll();
}

function addEdge(fromId, toId, weight) {
  // Prevent self-loops
  if (fromId === toId) {
    showValidation('Self-loops are not allowed.', 'warning');
    return null;
  }
  // Prevent duplicate edges (same from/to)
  const dup = graph.edges.find(e =>
    (e.from === fromId && e.to === toId) ||
    (!graph.directed && e.from === toId && e.to === fromId)
  );
  if (dup) {
    showValidation('An edge already exists between these nodes. Double-click edge to edit weight.', 'warning');
    return null;
  }
  const edge = { id: nextEdgeId++, from: fromId, to: toId, weight: Number(weight) };
  graph.edges.push(edge);
  invalidateResults();
  updateAll();
  return edge;
}

function removeEdge(id) {
  graph.edges = graph.edges.filter(e => e.id !== id);
  invalidateResults();
  updateAll();
}

function updateEdgeWeight(id, weight) {
  const edge = getEdge(id);
  if (edge) {
    edge.weight = Number(weight);
    invalidateResults();
    updateAll();
  }
}

function clearGraph() {
  graph.nodes = [];
  graph.edges = [];
  graph.source = null;
  graph.target = null;
  nextNodeId = 1;
  nextEdgeId = 1;
  invalidateResults();
  updateAll();
}

/** Build adjacency list from current graph. For undirected, adds both directions. */
function buildAdjacencyList() {
  const adj = {};
  for (const n of graph.nodes) adj[n.id] = [];
  for (const e of graph.edges) {
    adj[e.from].push({ to: e.to, weight: e.weight, edgeId: e.id });
    if (!graph.directed) {
      adj[e.to].push({ to: e.from, weight: e.weight, edgeId: e.id });
    }
  }
  return adj;
}

/** Build edge list for Bellman-Ford (directed / undirected both directions) */
function buildEdgeList() {
  const edges = [];
  for (const e of graph.edges) {
    edges.push({ from: e.from, to: e.to, weight: e.weight, edgeId: e.id });
    if (!graph.directed) {
      edges.push({ from: e.to, to: e.from, weight: e.weight, edgeId: e.id });
    }
  }
  return edges;
}

/** Reconstruct path from predecessor map. Returns null on cycle. */
function reconstructPath(prev, source, target) {
  const path = [];
  let cur = target;
  const visited = new Set();
  while (cur !== null && cur !== undefined) {
    if (visited.has(cur)) return null; // cycle in predecessor map
    visited.add(cur);
    path.unshift(cur);
    if (cur === source) break;
    cur = prev[cur];
  }
  if (path.length === 0 || path[0] !== source) return null;
  return path;
}

/** Verify a path is valid in the graph */
function verifyPath(path, totalCost, isBFS) {
  if (!path || path.length === 0) return false;
  let computedCost = 0;
  for (let i = 0; i < path.length - 1; i++) {
    const u = path[i], v = path[i + 1];
    const edge = graph.edges.find(e =>
      (e.from === u && e.to === v) ||
      (!graph.directed && e.from === v && e.to === u)
    );
    if (!edge) return false;
    computedCost += isBFS ? 1 : edge.weight;
  }
  if (!isBFS && Math.abs(computedCost - totalCost) > 1e-9) return false;
  return true;
}

/* ================================================================
   SECTION 3: ALGORITHM IMPLEMENTATIONS
================================================================ */

/* ── 3A: Dijkstra ─────────────────────────────────────────────── */
function runDijkstra(g, sourceId, targetId) {
  const nodes = g.nodes;
  const adj = {};
  for (const n of nodes) adj[n.id] = [];
  for (const e of g.edges) {
    adj[e.from].push({ to: e.to, weight: e.weight, edgeId: e.id });
    if (!g.directed) adj[e.to].push({ to: e.from, weight: e.weight, edgeId: e.id });
  }

  const dist = {}, prev = {}, visited = new Set();
  const ids = nodes.map(n => n.id);
  for (const id of ids) { dist[id] = INFINITY; prev[id] = null; }
  dist[sourceId] = 0;

  const events = [];

  // Init event
  events.push({
    type: 'init', title: 'Initialize', badge: 'init',
    description: `Set dist[${getNodeLabelFromG(g, sourceId)}] = 0, all others = ∞. Predecessor of all = nil.`,
    currentNode: null, visitedNodes: [], frontierNodes: [sourceId], exploredEdges: [], pathNodes: [], pathEdges: [],
    distances: { ...dist }, predecessors: { ...prev },
    algorithmSpecificState: { tentative: { ...dist }, finalized: new Set() },
    pseudocodeLine: [1, 2, 3],
  });

  const pseudoLineSelecting = [6, 7];
  const pseudoLineFinalize = [8];
  const pseudoLineExamine = [8, 9];
  const pseudoLineRelax = [10, 11, 12];

  while (true) {
    // Find unvisited node with min distance
    let u = null, minDist = INFINITY;
    for (const id of ids) {
      if (!visited.has(id) && dist[id] < minDist) {
        minDist = dist[id];
        u = id;
      }
    }
    if (u === null) break;

    visited.add(u);
    const finalized = new Set(visited);

    events.push({
      type: 'select', title: 'Select Minimum', badge: 'explore',
      description: `Selected ${getNodeLabelFromG(g, u)} with tentative distance ${distStr(dist[u])}. Marking as visited (finalized).`,
      currentNode: u, visitedNodes: [...visited], frontierNodes: ids.filter(id => !visited.has(id) && dist[id] < INFINITY),
      exploredEdges: [], pathNodes: [], pathEdges: [],
      distances: { ...dist }, predecessors: { ...prev },
      algorithmSpecificState: { tentative: { ...dist }, finalized: new Set(visited) },
      pseudocodeLine: pseudoLineSelecting,
    });

    if (u === targetId) {
      const path = reconstructPath(prev, sourceId, targetId);
      const pathEdges = getPathEdges(g, path);
      events.push({
        type: 'done', title: 'Target Reached', badge: 'done',
        description: `Reached target ${getNodeLabelFromG(g, targetId)}. Shortest distance = ${distStr(dist[targetId])}.`,
        currentNode: u, visitedNodes: [...visited], frontierNodes: [],
        exploredEdges: [],
        pathNodes: path || [], pathEdges,
        distances: { ...dist }, predecessors: { ...prev },
        algorithmSpecificState: { tentative: { ...dist }, finalized: new Set(visited), finalPath: path },
        pseudocodeLine: [],
      });
      break;
    }

    for (const { to: v, weight: w, edgeId } of (adj[u] || [])) {
      const alt = dist[u] + w;
      events.push({
        type: 'examine', title: 'Examine Edge', badge: 'explore',
        description: `Examining edge ${getNodeLabelFromG(g, u)} → ${getNodeLabelFromG(g, v)} (weight ${w}). alt = ${distStr(dist[u])} + ${w} = ${distStr(alt)} vs current dist[${getNodeLabelFromG(g, v)}] = ${distStr(dist[v])}`,
        currentNode: u, visitedNodes: [...visited], frontierNodes: ids.filter(id => !visited.has(id) && dist[id] < INFINITY),
        exploredEdges: [edgeId], pathNodes: [], pathEdges: [],
        distances: { ...dist }, predecessors: { ...prev },
        algorithmSpecificState: { tentative: { ...dist }, finalized: new Set(visited), examiningEdge: { u, v, w, edgeId } },
        pseudocodeLine: pseudoLineExamine,
      });

      if (alt < dist[v]) {
        const oldDist = dist[v];
        dist[v] = alt;
        prev[v] = u;
        events.push({
          type: 'relax', title: 'Edge Relaxed', badge: 'relax',
          description: `Improved! dist[${getNodeLabelFromG(g, v)}] updated from ${distStr(oldDist)} to ${distStr(alt)}. Predecessor set to ${getNodeLabelFromG(g, u)}.`,
          currentNode: u, visitedNodes: [...visited], frontierNodes: ids.filter(id => !visited.has(id) && dist[id] < INFINITY),
          exploredEdges: [edgeId], pathNodes: [], pathEdges: [],
          distances: { ...dist }, predecessors: { ...prev },
          algorithmSpecificState: { tentative: { ...dist }, finalized: new Set(visited), relaxedEdge: { u, v, edgeId } },
          pseudocodeLine: pseudoLineRelax,
        });
      }
    }
  }

  // Build final result
  const path = targetId ? reconstructPath(prev, sourceId, targetId) : null;
  const pathEdges = getPathEdges(g, path);
  const finalDistTarget = targetId ? dist[targetId] : null;

  if (!events.find(e => e.type === 'done') && path !== null && targetId) {
    events.push({
      type: 'done', title: 'Complete', badge: 'done',
      description: targetId && dist[targetId] === INFINITY
        ? `${getNodeLabelFromG(g, targetId)} is unreachable from ${getNodeLabelFromG(g, sourceId)}.`
        : `Algorithm complete.`,
      currentNode: null, visitedNodes: [...visited], frontierNodes: [],
      exploredEdges: [], pathNodes: path || [], pathEdges,
      distances: { ...dist }, predecessors: { ...prev },
      algorithmSpecificState: { tentative: { ...dist }, finalized: new Set(visited), finalPath: path },
      pseudocodeLine: [],
    });
  } else if (!events.find(e => e.type === 'done')) {
    events.push({
      type: 'done', title: 'Complete', badge: 'done',
      description: targetId && dist[targetId] === INFINITY
        ? `${getNodeLabelFromG(g, targetId)} is unreachable from ${getNodeLabelFromG(g, sourceId)}. All reachable nodes finalized.`
        : 'Dijkstra complete. All reachable nodes finalized.',
      currentNode: null, visitedNodes: [...visited], frontierNodes: [],
      exploredEdges: [], pathNodes: path || [], pathEdges,
      distances: { ...dist }, predecessors: { ...prev },
      algorithmSpecificState: { tentative: { ...dist }, finalized: new Set(visited), finalPath: path },
      pseudocodeLine: [],
    });
  }

  return {
    status: targetId && dist[targetId] === INFINITY ? 'unreachable' : 'ok',
    distances: dist,
    predecessors: prev,
    path,
    pathEdges,
    cost: finalDistTarget,
    events,
    negCycle: false,
  };
}

/* ── 3B: Bellman-Ford ─────────────────────────────────────────── */
function runBellmanFord(g, sourceId, targetId) {
  const nodes = g.nodes;
  const edges = [];
  for (const e of g.edges) {
    edges.push({ from: e.from, to: e.to, weight: e.weight, edgeId: e.id });
    if (!g.directed) edges.push({ from: e.to, to: e.from, weight: e.weight, edgeId: e.id });
  }
  const ids = nodes.map(n => n.id);
  const V = ids.length;

  const dist = {}, prev = {};
  for (const id of ids) { dist[id] = INFINITY; prev[id] = null; }
  dist[sourceId] = 0;

  const events = [];
  const visited = new Set([sourceId]);
  events.push({
    type: 'init', title: 'Initialize', badge: 'init',
    description: `dist[${getNodeLabelFromG(g, sourceId)}] = 0, all others = ∞.`,
    currentNode: null, visitedNodes: [...visited], frontierNodes: [sourceId], exploredEdges: [], pathNodes: [], pathEdges: [],
    distances: { ...dist }, predecessors: { ...prev },
    algorithmSpecificState: { pass: 0, totalPasses: V - 1 },
    pseudocodeLine: [1, 2, 3],
  });

  let negCycle = false;
  let negCycleEdge = null;

  for (let pass = 1; pass <= V - 1; pass++) {
    let changed = false;
    events.push({
      type: 'pass-start', title: `Pass ${pass} of ${V - 1}`, badge: 'explore',
      description: `Starting relaxation pass ${pass}. Will examine all ${edges.length} directed edges.`,
      currentNode: null, visitedNodes: [...visited], frontierNodes: [], exploredEdges: [], pathNodes: [], pathEdges: [],
      distances: { ...dist }, predecessors: { ...prev },
      algorithmSpecificState: { pass, totalPasses: V - 1 },
      pseudocodeLine: [4, 5],
    });

    for (const { from: u, to: v, weight: w, edgeId } of edges) {
      if (dist[u] === INFINITY) continue;
      const alt = dist[u] + w;
      events.push({
        type: 'examine', title: 'Examine Edge', badge: 'explore',
        description: `Pass ${pass}: Edge ${getNodeLabelFromG(g, u)} → ${getNodeLabelFromG(g, v)} (w=${w}). dist[${getNodeLabelFromG(g, u)}]+${w}=${distStr(alt)} vs dist[${getNodeLabelFromG(g, v)}]=${distStr(dist[v])}`,
        currentNode: u, visitedNodes: [...visited], frontierNodes: [], exploredEdges: [edgeId], pathNodes: [], pathEdges: [],
        distances: { ...dist }, predecessors: { ...prev },
        algorithmSpecificState: { pass, totalPasses: V - 1, examiningEdge: { u, v, w } },
        pseudocodeLine: [6, 7],
      });

      if (alt < dist[v]) {
        dist[v] = alt;
        prev[v] = u;
        visited.add(v);
        changed = true;
        events.push({
          type: 'relax', title: 'Relaxed', badge: 'relax',
          description: `Improved! dist[${getNodeLabelFromG(g, v)}] = ${distStr(alt)}. Predecessor = ${getNodeLabelFromG(g, u)}.`,
          currentNode: u, visitedNodes: [...visited], frontierNodes: [], exploredEdges: [edgeId], pathNodes: [], pathEdges: [],
          distances: { ...dist }, predecessors: { ...prev },
          algorithmSpecificState: { pass, totalPasses: V - 1 },
          pseudocodeLine: [8, 9, 10],
        });
      }
    }

    if (!changed) {
      events.push({
        type: 'early-exit', title: 'Early Exit', badge: 'done',
        description: `No distances changed in pass ${pass}. Algorithm converged early! Stopping after ${pass} passes instead of ${V - 1}.`,
        currentNode: null, visitedNodes: [...visited], frontierNodes: [], exploredEdges: [], pathNodes: [], pathEdges: [],
        distances: { ...dist }, predecessors: { ...prev },
        algorithmSpecificState: { pass, totalPasses: V - 1, earlyExit: true },
        pseudocodeLine: [11],
      });
      break;
    }
  }

  // Negative cycle detection
  events.push({
    type: 'neg-check', title: 'Negative Cycle Check', badge: 'explore',
    description: `Performing extra relaxation pass to detect negative cycles reachable from source.`,
    currentNode: null, visitedNodes: [...visited], frontierNodes: [], exploredEdges: [], pathNodes: [], pathEdges: [],
    distances: { ...dist }, predecessors: { ...prev },
    algorithmSpecificState: { negCycleCheck: true },
    pseudocodeLine: [12, 13, 14],
  });

  for (const { from: u, to: v, weight: w, edgeId } of edges) {
    if (dist[u] === INFINITY) continue;
    if (dist[u] + w < dist[v]) {
      negCycle = true;
      negCycleEdge = { u, v, w, edgeId };
      break;
    }
  }

  if (negCycle) {
    events.push({
      type: 'neg-cycle', title: 'Negative Cycle Detected!', badge: 'error',
      description: `NEGATIVE CYCLE detected! Edge ${getNodeLabelFromG(g, negCycleEdge.u)} → ${getNodeLabelFromG(g, negCycleEdge.v)} (w=${negCycleEdge.w}) can still be relaxed. Shortest paths are undefined for affected vertices.`,
      currentNode: null, visitedNodes: [...visited], frontierNodes: [], exploredEdges: [negCycleEdge.edgeId], pathNodes: [], pathEdges: [],
      distances: { ...dist }, predecessors: { ...prev },
      algorithmSpecificState: { negCycle: true, negCycleEdge },
      pseudocodeLine: [15],
    });
    return { status: 'neg-cycle', distances: dist, predecessors: prev, path: null, pathEdges: [], cost: null, events, negCycle: true };
  }

  const path = targetId ? reconstructPath(prev, sourceId, targetId) : null;
  const pathEdges = getPathEdges(g, path);

  events.push({
    type: 'done', title: 'Complete', badge: 'done',
    description: targetId && dist[targetId] === INFINITY
      ? `${getNodeLabelFromG(g, targetId)} is unreachable.`
      : targetId ? `Shortest path from ${getNodeLabelFromG(g, sourceId)} to ${getNodeLabelFromG(g, targetId)} = ${distStr(dist[targetId])}.`
        : `Bellman-Ford complete. All reachable distances computed.`,
    currentNode: null, visitedNodes: [...visited], frontierNodes: [], exploredEdges: [], pathNodes: path || [], pathEdges,
    distances: { ...dist }, predecessors: { ...prev },
    algorithmSpecificState: { finalPath: path },
    pseudocodeLine: [],
  });

  return {
    status: targetId && dist[targetId] === INFINITY ? 'unreachable' : 'ok',
    distances: dist, predecessors: prev, path, pathEdges,
    cost: targetId ? dist[targetId] : null, events, negCycle: false,
  };
}

/* ── 3C: BFS ──────────────────────────────────────────────────── */
function runBFS(g, sourceId, targetId) {
  const ids = g.nodes.map(n => n.id);
  const adj = {};
  for (const id of ids) adj[id] = [];
  for (const e of g.edges) {
    adj[e.from].push({ to: e.to, edgeId: e.id });
    if (!g.directed) adj[e.to].push({ to: e.from, edgeId: e.id });
  }

  const dist = {}, prev = {}, discovered = {};
  for (const id of ids) { dist[id] = INFINITY; prev[id] = null; discovered[id] = false; }
  dist[sourceId] = 0;
  discovered[sourceId] = true;

  const events = [];
  const queue = [sourceId];
  const visited = new Set([sourceId]);

  events.push({
    type: 'init', title: 'Initialize Queue', badge: 'init',
    description: `Enqueue source ${getNodeLabelFromG(g, sourceId)}. dist[${getNodeLabelFromG(g, sourceId)}] = 0 hops. All others undiscovered.`,
    currentNode: null, visitedNodes: [], frontierNodes: [sourceId], exploredEdges: [], pathNodes: [], pathEdges: [],
    distances: { ...dist }, predecessors: { ...prev },
    algorithmSpecificState: { queue: [...queue] },
    pseudocodeLine: [1, 2, 3, 4, 5],
  });

  while (queue.length > 0) {
    const u = queue.shift();
    events.push({
      type: 'dequeue', title: 'Dequeue', badge: 'explore',
      description: `Dequeued ${getNodeLabelFromG(g, u)} (dist=${distStr(dist[u])} hops). Queue: [${queue.map(id => getNodeLabelFromG(g, id)).join(', ')}]`,
      currentNode: u, visitedNodes: [...visited], frontierNodes: [...queue], exploredEdges: [], pathNodes: [], pathEdges: [],
      distances: { ...dist }, predecessors: { ...prev },
      algorithmSpecificState: { queue: [...queue] },
      pseudocodeLine: [7],
    });

    if (u === targetId) {
      const path = reconstructPath(prev, sourceId, targetId);
      const pathEdges = getPathEdges(g, path, true);
      events.push({
        type: 'done', title: 'Target Found', badge: 'done',
        description: `Reached target ${getNodeLabelFromG(g, targetId)} via BFS. Shortest path = ${dist[targetId]} hops.`,
        currentNode: u, visitedNodes: [...visited], frontierNodes: [],
        exploredEdges: [], pathNodes: path || [], pathEdges,
        distances: { ...dist }, predecessors: { ...prev },
        algorithmSpecificState: { queue: [], finalPath: path },
        pseudocodeLine: [],
      });
      return { status: 'ok', distances: dist, predecessors: prev, path, pathEdges, cost: dist[targetId], events, negCycle: false };
    }

    for (const { to: v, edgeId } of (adj[u] || [])) {
      events.push({
        type: 'inspect', title: 'Inspect Edge', badge: 'explore',
        description: `Inspecting edge ${getNodeLabelFromG(g, u)} → ${getNodeLabelFromG(g, v)}. ${discovered[v] ? 'Already discovered — skip.' : 'Not discovered — enqueue.'}`,
        currentNode: u, visitedNodes: [...visited], frontierNodes: [...queue], exploredEdges: [edgeId], pathNodes: [], pathEdges: [],
        distances: { ...dist }, predecessors: { ...prev },
        algorithmSpecificState: { queue: [...queue] },
        pseudocodeLine: [8, 9],
      });

      if (!discovered[v]) {
        discovered[v] = true;
        dist[v] = dist[u] + 1;
        prev[v] = u;
        queue.push(v);
        visited.add(v);
        events.push({
          type: 'discover', title: 'Discover', badge: 'relax',
          description: `Discovered ${getNodeLabelFromG(g, v)}! dist = ${dist[v]} hops, predecessor = ${getNodeLabelFromG(g, u)}. Queue: [${queue.map(id => getNodeLabelFromG(g, id)).join(', ')}]`,
          currentNode: u, visitedNodes: [...visited], frontierNodes: [...queue], exploredEdges: [edgeId], pathNodes: [], pathEdges: [],
          distances: { ...dist }, predecessors: { ...prev },
          algorithmSpecificState: { queue: [...queue] },
          pseudocodeLine: [10, 11, 12, 13],
        });
      }
    }
  }

  const path = targetId ? reconstructPath(prev, sourceId, targetId) : null;
  const pathEdges = getPathEdges(g, path, true);

  events.push({
    type: 'done', title: 'BFS Complete', badge: targetId && dist[targetId] === INFINITY ? 'error' : 'done',
    description: targetId && dist[targetId] === INFINITY
      ? `${getNodeLabelFromG(g, targetId)} is unreachable from ${getNodeLabelFromG(g, sourceId)}.`
      : `BFS complete. Note: distances represent hop counts, not weighted costs.`,
    currentNode: null, visitedNodes: [...visited], frontierNodes: [],
    exploredEdges: [], pathNodes: path || [], pathEdges,
    distances: { ...dist }, predecessors: { ...prev },
    algorithmSpecificState: { queue: [], finalPath: path },
    pseudocodeLine: [],
  });

  return {
    status: targetId && dist[targetId] === INFINITY ? 'unreachable' : 'ok',
    distances: dist, predecessors: prev, path, pathEdges,
    cost: targetId ? dist[targetId] : null, events, negCycle: false,
  };
}

/* ── 3D: Floyd-Warshall ───────────────────────────────────────── */
function runFloydWarshall(g) {
  const nodes = g.nodes;
  const n = nodes.length;
  const ids = nodes.map(nd => nd.id);
  const idx = {}; // id → matrix index
  ids.forEach((id, i) => { idx[id] = i; });

  // Initialize D and next matrices
  const D = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => i === j ? 0 : INFINITY));
  const nxt = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => i === j ? i : null));

  for (const e of g.edges) {
    const fi = idx[e.from], ti = idx[e.to];
    if (fi === undefined || ti === undefined) continue;
    if (e.weight < D[fi][ti]) {
      D[fi][ti] = e.weight;
      nxt[fi][ti] = ti;
    }
    if (!g.directed && e.weight < D[ti][fi]) {
      D[ti][fi] = e.weight;
      nxt[ti][fi] = fi;
    }
  }

  const events = [];
  const matSnapshot = () => D.map(row => [...row]);

  events.push({
    type: 'init', title: 'Initialize Matrix', badge: 'init',
    description: `Created ${n}×${n} distance matrix D. D[i][i]=0, D[i][j]=weight if direct edge exists, else ∞.`,
    currentNode: null, visitedNodes: [], frontierNodes: [], exploredEdges: [], pathNodes: [], pathEdges: [],
    distances: {}, predecessors: {},
    algorithmSpecificState: { k: null, matrix: matSnapshot(), ids, idx },
    pseudocodeLine: [1, 2, 3, 4],
  });

  let negCycle = false;

  for (let k = 0; k < n; k++) {
    const kLabel = getNodeLabelFromG(g, ids[k]);
    events.push({
      type: 'fw-k', title: `Intermediate: ${kLabel}`, badge: 'explore',
      description: `Using vertex ${kLabel} (index ${k}) as intermediate. Checking if routing through ${kLabel} improves any i→j path.`,
      currentNode: ids[k], visitedNodes: [], frontierNodes: [], exploredEdges: [], pathNodes: [], pathEdges: [],
      distances: {}, predecessors: {},
      algorithmSpecificState: { k, kId: ids[k], matrix: matSnapshot(), ids, idx },
      pseudocodeLine: [5],
    });

    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        if (D[i][k] === INFINITY || D[k][j] === INFINITY) continue;
        const candidate = D[i][k] + D[k][j];
        if (candidate < D[i][j]) {
          const oldVal = D[i][j];
          D[i][j] = candidate;
          nxt[i][j] = nxt[i][k];
          events.push({
            type: 'fw-update', title: 'Matrix Update', badge: 'relax',
            description: `D[${getNodeLabelFromG(g, ids[i])}][${getNodeLabelFromG(g, ids[j])}] updated: ${distStr(oldVal)} → ${distStr(candidate)} via ${kLabel}.`,
            currentNode: ids[k], visitedNodes: [], frontierNodes: [], exploredEdges: [], pathNodes: [], pathEdges: [],
            distances: {}, predecessors: {},
            algorithmSpecificState: { k, kId: ids[k], i, j, iId: ids[i], jId: ids[j], matrix: matSnapshot(), ids, idx },
            pseudocodeLine: [8, 9, 10],
          });
        }
      }
    }
  }

  // Check negative diagonal
  for (let i = 0; i < n; i++) {
    if (D[i][i] < 0) { negCycle = true; break; }
  }

  events.push({
    type: 'done', title: negCycle ? 'Negative Cycle Detected!' : 'Complete', badge: negCycle ? 'error' : 'done',
    description: negCycle
      ? `Negative cycle detected (D[i][i] < 0 for some i). Affected pairs have undefined shortest paths.`
      : `Floyd-Warshall complete. All-pairs shortest paths computed.`,
    currentNode: null, visitedNodes: [], frontierNodes: [], exploredEdges: [], pathNodes: [], pathEdges: [],
    distances: {}, predecessors: {},
    algorithmSpecificState: { matrix: matSnapshot(), ids, idx, negCycle, nxt },
    pseudocodeLine: negCycle ? [11, 12] : [],
  });

  return { status: negCycle ? 'neg-cycle' : 'ok', matrix: D, nxt, ids, idx, events, negCycle };
}

/** Reconstruct FW path from nxt matrix */
function reconstructFWPath(nxt, si, ti) {
  if (nxt[si][ti] === null) return null;
  const path = [si];
  let cur = si;
  const visited = new Set([si]);
  while (cur !== ti) {
    cur = nxt[cur][ti];
    if (cur === null) return null;
    if (visited.has(cur)) return null; // cycle
    visited.add(cur);
    path.push(cur);
    if (path.length > 100) return null;
  }
  return path; // indices
}

/* ── 3E: A* ───────────────────────────────────────────────────── */
function runAStar(g, sourceId, targetId, heuristicType) {
  const ids = g.nodes.map(n => n.id);
  const nodeMap = {};
  for (const nd of g.nodes) nodeMap[nd.id] = nd;

  const adj = {};
  for (const id of ids) adj[id] = [];
  for (const e of g.edges) {
    adj[e.from].push({ to: e.to, weight: e.weight, edgeId: e.id });
    if (!g.directed) adj[e.to].push({ to: e.from, weight: e.weight, edgeId: e.id });
  }

  const targetNode = nodeMap[targetId];

  // Scale geometric heuristics by the smallest weight-per-pixel ratio so they stay admissible.
  let hScale = Infinity;
  for (const e of g.edges) {
    const a = nodeMap[e.from], b = nodeMap[e.to];
    if (!a || !b) continue;
    const d = Math.hypot(a.x - b.x, a.y - b.y);
    if (d > 0) hScale = Math.min(hScale, e.weight / d);
  }
  if (!isFinite(hScale) || hScale < 0) hScale = 0;

  function heuristic(nodeId) {
    if (heuristicType === 'zero') return 0;
    const nd = nodeMap[nodeId];
    if (!nd || !targetNode) return 0;
    const dx = nd.x - targetNode.x, dy = nd.y - targetNode.y;
    if (heuristicType === 'euclidean') return Math.sqrt(dx * dx + dy * dy) * hScale;
    if (heuristicType === 'manhattan') return (Math.abs(dx) + Math.abs(dy)) * hScale / Math.SQRT2;
    return 0;
  }

  const gScore = {}, fScore = {}, prev = {};
  for (const id of ids) { gScore[id] = INFINITY; fScore[id] = INFINITY; prev[id] = null; }
  gScore[sourceId] = 0;
  fScore[sourceId] = heuristic(sourceId);

  const open = new Set([sourceId]);
  const closed = new Set();
  const events = [];

  const hVals = {};
  for (const id of ids) hVals[id] = heuristic(id);

  events.push({
    type: 'init', title: 'Initialize A*', badge: 'init',
    description: `g[${getNodeLabelFromG(g, sourceId)}]=0, h[${getNodeLabelFromG(g, sourceId)}]=${hVals[sourceId].toFixed(2)}, f[${getNodeLabelFromG(g, sourceId)}]=${fScore[sourceId].toFixed(2)}. Open={${getNodeLabelFromG(g, sourceId)}}.`,
    currentNode: null, visitedNodes: [], frontierNodes: [sourceId], exploredEdges: [], pathNodes: [], pathEdges: [],
    distances: { ...gScore }, predecessors: { ...prev },
    algorithmSpecificState: { gScore: { ...gScore }, hScore: { ...hVals }, fScore: { ...fScore }, open: new Set(open), closed: new Set(closed) },
    pseudocodeLine: [1, 2, 3, 4],
  });

  while (open.size > 0) {
    // Find node in open with min fScore
    let u = null, minF = INFINITY;
    for (const id of open) {
      if (fScore[id] < minF) { minF = fScore[id]; u = id; }
    }
    if (u === null) break;

    events.push({
      type: 'select', title: 'Expand Node', badge: 'explore',
      description: `Expanding ${getNodeLabelFromG(g, u)}: g=${distStr(gScore[u])}, h=${hVals[u].toFixed(2)}, f=${fScore[u].toFixed(2)}. Open set size: ${open.size}.`,
      currentNode: u, visitedNodes: [...closed], frontierNodes: [...open].filter(id => id !== u),
      exploredEdges: [], pathNodes: [], pathEdges: [],
      distances: { ...gScore }, predecessors: { ...prev },
      algorithmSpecificState: { gScore: { ...gScore }, hScore: { ...hVals }, fScore: { ...fScore }, open: new Set(open), closed: new Set(closed) },
      pseudocodeLine: [6, 7],
    });

    if (u === targetId) {
      const path = reconstructPath(prev, sourceId, targetId);
      const pathEdges = getPathEdges(g, path);
      events.push({
        type: 'done', title: 'Target Reached', badge: 'done',
        description: `A* reached target ${getNodeLabelFromG(g, targetId)}! Cost = ${distStr(gScore[targetId])}.`,
        currentNode: u, visitedNodes: [...closed], frontierNodes: [...open],
        exploredEdges: [], pathNodes: path || [], pathEdges,
        distances: { ...gScore }, predecessors: { ...prev },
        algorithmSpecificState: { gScore: { ...gScore }, hScore: { ...hVals }, fScore: { ...fScore }, open: new Set(open), closed: new Set(closed), finalPath: path },
        pseudocodeLine: [8, 9],
      });
      return { status: 'ok', distances: gScore, predecessors: prev, path, pathEdges, cost: gScore[targetId], events, negCycle: false };
    }

    open.delete(u);
    closed.add(u);

    for (const { to: v, weight: w, edgeId } of (adj[u] || [])) {
      if (w < 0) continue; // A* baseline: non-negative only
      const tentG = gScore[u] + w;
      events.push({
        type: 'examine', title: 'Inspect Neighbor', badge: 'explore',
        description: `Edge ${getNodeLabelFromG(g, u)}→${getNodeLabelFromG(g, v)} (w=${w}). tentative_g=${distStr(tentG)}, current g[${getNodeLabelFromG(g, v)}]=${distStr(gScore[v])}.`,
        currentNode: u, visitedNodes: [...closed], frontierNodes: [...open],
        exploredEdges: [edgeId], pathNodes: [], pathEdges: [],
        distances: { ...gScore }, predecessors: { ...prev },
        algorithmSpecificState: { gScore: { ...gScore }, hScore: { ...hVals }, fScore: { ...fScore }, open: new Set(open), closed: new Set(closed) },
        pseudocodeLine: [11, 12],
      });

      if (closed.has(v) && tentG >= gScore[v]) continue;
      if (tentG < gScore[v]) {
        gScore[v] = tentG;
        fScore[v] = tentG + hVals[v];
        prev[v] = u;
        closed.delete(v);
        open.add(v);
        events.push({
          type: 'relax', title: 'Update Score', badge: 'relax',
          description: `Updated ${getNodeLabelFromG(g, v)}: g=${distStr(tentG)}, h=${hVals[v].toFixed(2)}, f=${fScore[v].toFixed(2)}. Added to open set.`,
          currentNode: u, visitedNodes: [...closed], frontierNodes: [...open],
          exploredEdges: [edgeId], pathNodes: [], pathEdges: [],
          distances: { ...gScore }, predecessors: { ...prev },
          algorithmSpecificState: { gScore: { ...gScore }, hScore: { ...hVals }, fScore: { ...fScore }, open: new Set(open), closed: new Set(closed) },
          pseudocodeLine: [14, 15, 16, 17],
        });
      }
    }
  }

  events.push({
    type: 'done', title: 'No Path Found', badge: 'error',
    description: `Open set exhausted. ${getNodeLabelFromG(g, targetId)} is unreachable from ${getNodeLabelFromG(g, sourceId)}.`,
    currentNode: null, visitedNodes: [...closed], frontierNodes: [],
    exploredEdges: [], pathNodes: [], pathEdges: [],
    distances: { ...gScore }, predecessors: { ...prev },
    algorithmSpecificState: { gScore: { ...gScore }, hScore: { ...hVals }, fScore: { ...fScore }, open: new Set(), closed: new Set(closed) },
    pseudocodeLine: [18],
  });

  return { status: 'unreachable', distances: gScore, predecessors: prev, path: null, pathEdges: [], cost: null, events, negCycle: false };
}

/* ── 3F: DAG Shortest Path ────────────────────────────────────── */
function topologicalSort(g) {
  // Kahn's algorithm
  const ids = g.nodes.map(n => n.id);
  const inDeg = {};
  for (const id of ids) inDeg[id] = 0;
  for (const e of g.edges) {
    inDeg[e.to] = (inDeg[e.to] || 0) + 1;
  }

  const queue = ids.filter(id => inDeg[id] === 0);
  const order = [];

  while (queue.length > 0) {
    const u = queue.shift();
    order.push(u);
    for (const e of g.edges) {
      if (e.from !== u) continue;
      inDeg[e.to]--;
      if (inDeg[e.to] === 0) queue.push(e.to);
    }
  }

  return { order, isCyclic: order.length !== ids.length };
}

function runDAG(g, sourceId, targetId) {
  const events = [];
  const ids = g.nodes.map(n => n.id);

  // Require directed
  if (!g.directed) {
    events.push({
      type: 'error', title: 'Error: Undirected Graph', badge: 'error',
      description: 'DAG Shortest Path requires a directed graph. Please enable "Directed" mode.',
      currentNode: null, visitedNodes: [], frontierNodes: [], exploredEdges: [], pathNodes: [], pathEdges: [],
      distances: {}, predecessors: {},
      algorithmSpecificState: {},
      pseudocodeLine: [],
    });
    return { status: 'error', error: 'Requires directed graph.', events };
  }

  // Topological sort
  const { order, isCyclic } = topologicalSort(g);

  events.push({
    type: 'topo', title: 'Topological Sort', badge: 'explore',
    description: isCyclic
      ? `Cycle detected! Could only order ${order.length} of ${ids.length} vertices. Graph is NOT a DAG.`
      : `Topological order: ${order.map(id => getNodeLabelFromG(g, id)).join(' → ')}. Graph is a valid DAG.`,
    currentNode: null, visitedNodes: [], frontierNodes: [], exploredEdges: [], pathNodes: [], pathEdges: [],
    distances: {}, predecessors: {},
    algorithmSpecificState: { topoOrder: order, isCyclic },
    pseudocodeLine: [1, 2],
  });

  if (isCyclic) {
    return { status: 'error', error: 'Graph contains a cycle — not a DAG.', events };
  }

  const dist = {}, prev = {};
  for (const id of ids) { dist[id] = INFINITY; prev[id] = null; }
  dist[sourceId] = 0;

  events.push({
    type: 'init', title: 'Initialize Distances', badge: 'init',
    description: `dist[${getNodeLabelFromG(g, sourceId)}]=0, all others=∞. Processing vertices in topological order.`,
    currentNode: null, visitedNodes: [], frontierNodes: [sourceId], exploredEdges: [], pathNodes: [], pathEdges: [],
    distances: { ...dist }, predecessors: { ...prev },
    algorithmSpecificState: { topoOrder: order, topoPos: 0 },
    pseudocodeLine: [3, 4, 5],
  });

  for (let pos = 0; pos < order.length; pos++) {
    const u = order[pos];
    if (dist[u] === INFINITY) {
      events.push({
        type: 'skip', title: 'Skip Unreachable', badge: 'explore',
        description: `Skip ${getNodeLabelFromG(g, u)} — unreachable (dist=∞). Cannot relax outgoing edges from unreachable vertex.`,
        currentNode: u, visitedNodes: [], frontierNodes: [], exploredEdges: [], pathNodes: [], pathEdges: [],
        distances: { ...dist }, predecessors: { ...prev },
        algorithmSpecificState: { topoOrder: order, topoPos: pos },
        pseudocodeLine: [7],
      });
      continue;
    }

    events.push({
      type: 'process', title: `Process: ${getNodeLabelFromG(g, u)}`, badge: 'explore',
      description: `Processing ${getNodeLabelFromG(g, u)} (dist=${distStr(dist[u])}). Relaxing outgoing edges.`,
      currentNode: u, visitedNodes: order.slice(0, pos), frontierNodes: [], exploredEdges: [], pathNodes: [], pathEdges: [],
      distances: { ...dist }, predecessors: { ...prev },
      algorithmSpecificState: { topoOrder: order, topoPos: pos },
      pseudocodeLine: [6],
    });

    const outgoing = g.edges.filter(e => e.from === u);
    for (const e of outgoing) {
      const v = e.to, w = e.weight;
      const alt = dist[u] + w;
      events.push({
        type: 'examine', title: 'Examine Edge', badge: 'explore',
        description: `Edge ${getNodeLabelFromG(g, u)}→${getNodeLabelFromG(g, v)} (w=${w}). alt=${distStr(alt)}, dist[${getNodeLabelFromG(g, v)}]=${distStr(dist[v])}.`,
        currentNode: u, visitedNodes: order.slice(0, pos), frontierNodes: [], exploredEdges: [e.id], pathNodes: [], pathEdges: [],
        distances: { ...dist }, predecessors: { ...prev },
        algorithmSpecificState: { topoOrder: order, topoPos: pos },
        pseudocodeLine: [8, 9],
      });

      if (alt < dist[v]) {
        dist[v] = alt;
        prev[v] = u;
        events.push({
          type: 'relax', title: 'Relaxed', badge: 'relax',
          description: `Relaxed! dist[${getNodeLabelFromG(g, v)}] = ${distStr(alt)}, predecessor = ${getNodeLabelFromG(g, u)}.`,
          currentNode: u, visitedNodes: order.slice(0, pos), frontierNodes: [], exploredEdges: [e.id], pathNodes: [], pathEdges: [],
          distances: { ...dist }, predecessors: { ...prev },
          algorithmSpecificState: { topoOrder: order, topoPos: pos },
          pseudocodeLine: [10, 11],
        });
      }
    }
  }

  const path = targetId ? reconstructPath(prev, sourceId, targetId) : null;
  const pathEdges = getPathEdges(g, path);

  events.push({
    type: 'done', title: 'DAG Complete', badge: 'done',
    description: targetId && dist[targetId] === INFINITY
      ? `${getNodeLabelFromG(g, targetId)} is unreachable.`
      : targetId ? `Shortest path = ${distStr(dist[targetId])}.` : `DAG shortest paths computed.`,
    currentNode: null, visitedNodes: [...order], frontierNodes: [],
    exploredEdges: [], pathNodes: path || [], pathEdges,
    distances: { ...dist }, predecessors: { ...prev },
    algorithmSpecificState: { topoOrder: order, finalPath: path },
    pseudocodeLine: [],
  });

  return {
    status: targetId && dist[targetId] === INFINITY ? 'unreachable' : 'ok',
    distances: dist, predecessors: prev, path, pathEdges,
    cost: targetId ? dist[targetId] : null, events, negCycle: false,
  };
}

/* ── 3G: 0-1 BFS ──────────────────────────────────────────────── */
function run01BFS(g, sourceId, targetId) {
  const ids = g.nodes.map(n => n.id);
  const adj = {};
  for (const id of ids) adj[id] = [];
  for (const e of g.edges) {
    adj[e.from].push({ to: e.to, weight: e.weight, edgeId: e.id });
    if (!g.directed) adj[e.to].push({ to: e.from, weight: e.weight, edgeId: e.id });
  }

  const dist = {}, prev = {};
  for (const id of ids) { dist[id] = INFINITY; prev[id] = null; }
  dist[sourceId] = 0;

  const deque = [sourceId];
  const events = [];

  events.push({
    type: 'init', title: 'Initialize Deque', badge: 'init',
    description: `dist[${getNodeLabelFromG(g, sourceId)}]=0, all others=∞. Deque initialized with source: [${getNodeLabelFromG(g, sourceId)}].`,
    currentNode: null, visitedNodes: [], frontierNodes: [sourceId], exploredEdges: [], pathNodes: [], pathEdges: [],
    distances: { ...dist }, predecessors: { ...prev },
    algorithmSpecificState: { deque: [...deque] },
    pseudocodeLine: [1, 2, 3, 4],
  });

  const finalized = new Set();

  while (deque.length > 0) {
    const u = deque.shift();
    if (finalized.has(u)) continue;
    finalized.add(u);

    events.push({
      type: 'pop', title: 'Pop Front', badge: 'explore',
      description: `Pop ${getNodeLabelFromG(g, u)} from front (dist=${distStr(dist[u])}). Deque: [${deque.map(id => getNodeLabelFromG(g, id)).join(', ')}]`,
      currentNode: u, visitedNodes: [...finalized], frontierNodes: [...deque], exploredEdges: [], pathNodes: [], pathEdges: [],
      distances: { ...dist }, predecessors: { ...prev },
      algorithmSpecificState: { deque: [...deque] },
      pseudocodeLine: [6, 7],
    });

    for (const { to: v, weight: w, edgeId } of (adj[u] || [])) {
      const alt = dist[u] + w;
      events.push({
        type: 'examine', title: 'Examine Edge', badge: 'explore',
        description: `Edge ${getNodeLabelFromG(g, u)}→${getNodeLabelFromG(g, v)} (w=${w}). alt=${distStr(alt)}, dist[${getNodeLabelFromG(g, v)}]=${distStr(dist[v])}.`,
        currentNode: u, visitedNodes: [...finalized], frontierNodes: [...deque], exploredEdges: [edgeId], pathNodes: [], pathEdges: [],
        distances: { ...dist }, predecessors: { ...prev },
        algorithmSpecificState: { deque: [...deque] },
        pseudocodeLine: [8, 9],
      });

      if (alt < dist[v]) {
        dist[v] = alt;
        prev[v] = u;
        if (w === 0) {
          deque.unshift(v);
          events.push({
            type: 'push-front', title: 'Push Front (w=0)', badge: 'relax',
            description: `w=0: Push ${getNodeLabelFromG(g, v)} to FRONT of deque. dist[${getNodeLabelFromG(g, v)}]=${distStr(alt)}.`,
            currentNode: u, visitedNodes: [...finalized], frontierNodes: [...deque], exploredEdges: [edgeId], pathNodes: [], pathEdges: [],
            distances: { ...dist }, predecessors: { ...prev },
            algorithmSpecificState: { deque: [...deque], frontPush: true },
            pseudocodeLine: [10, 11, 12, 13],
          });
        } else {
          deque.push(v);
          events.push({
            type: 'push-back', title: 'Push Back (w=1)', badge: 'relax',
            description: `w=1: Push ${getNodeLabelFromG(g, v)} to BACK of deque. dist[${getNodeLabelFromG(g, v)}]=${distStr(alt)}.`,
            currentNode: u, visitedNodes: [...finalized], frontierNodes: [...deque], exploredEdges: [edgeId], pathNodes: [], pathEdges: [],
            distances: { ...dist }, predecessors: { ...prev },
            algorithmSpecificState: { deque: [...deque], frontPush: false },
            pseudocodeLine: [10, 11, 12, 14],
          });
        }
      }
    }
  }

  const path = targetId ? reconstructPath(prev, sourceId, targetId) : null;
  const pathEdges = getPathEdges(g, path);

  events.push({
    type: 'done', title: '0-1 BFS Complete', badge: targetId && dist[targetId] === INFINITY ? 'error' : 'done',
    description: targetId && dist[targetId] === INFINITY
      ? `${getNodeLabelFromG(g, targetId)} is unreachable.`
      : targetId ? `Shortest path = ${distStr(dist[targetId])}.` : `0-1 BFS complete.`,
    currentNode: null, visitedNodes: [...finalized], frontierNodes: [],
    exploredEdges: [], pathNodes: path || [], pathEdges,
    distances: { ...dist }, predecessors: { ...prev },
    algorithmSpecificState: { deque: [], finalPath: path },
    pseudocodeLine: [],
  });

  return {
    status: targetId && dist[targetId] === INFINITY ? 'unreachable' : 'ok',
    distances: dist, predecessors: prev, path, pathEdges,
    cost: targetId ? dist[targetId] : null, events, negCycle: false,
  };
}

/* ── Helpers ──────────────────────────────────────────────────── */
function distStr(d) {
  if (d === undefined || d === null) return '—';
  if (d === INFINITY) return INF_DISPLAY;
  return Number.isInteger(d) ? String(d) : String(Math.round(d * 1000) / 1000);
}

function isWeighted() { return document.getElementById('chk-weighted').checked; }

function getNodeLabelFromG(g, id) {
  const nd = g.nodes.find(n => n.id === id);
  return nd ? nd.label : String(id);
}

function getPathEdges(g, path, undirectedOk) {
  if (!path || path.length < 2) return [];
  const edgeIds = [];
  for (let i = 0; i < path.length - 1; i++) {
    const u = path[i], v = path[i + 1];
    const e = g.edges.find(e =>
      (e.from === u && e.to === v) ||
      ((!g.directed || undirectedOk) && e.from === v && e.to === u)
    );
    if (e) edgeIds.push(e.id);
  }
  return edgeIds;
}

/* ================================================================
   SECTION 4: VALIDATION
================================================================ */

function validateForAlgorithm(algoId) {
  const errors = [], warnings = [], infos = [];
  const meta = ALGO_META[algoId];
  if (!meta) return { errors, warnings, infos };

  const nodeCount = graph.nodes.length;
  const edgeCount = graph.edges.length;

  if (nodeCount === 0) {
    errors.push('Graph is empty. Add at least one vertex.');
    return { errors, warnings, infos };
  }

  if (meta.requiresDirected && !graph.directed) {
    errors.push('This algorithm requires a directed graph. Enable "Directed" mode.');
  }

  if (meta.requiresSource && !graph.source) {
    errors.push('A source vertex must be selected.');
  }

  if (meta.requiresTarget && !graph.target) {
    errors.push('A target (destination) vertex must be selected.');
  }

  if (graph.source && !graph.nodes.find(n => n.id === graph.source)) {
    errors.push('Selected source vertex no longer exists.');
    graph.source = null;
  }

  if (graph.target && !graph.nodes.find(n => n.id === graph.target)) {
    errors.push('Selected target vertex no longer exists.');
    graph.target = null;
  }

  const ew = e => (isWeighted() ? e.weight : 1);
  const hasNegative = graph.edges.some(e => ew(e) < 0);
  const hasNonBinary = graph.edges.some(e => ew(e) !== 0 && ew(e) !== 1);

  if (meta.requiresNonNegative && hasNegative) {
    errors.push('This algorithm requires all edge weights ≥ 0. Negative weights detected.');
  }

  if (meta.requires01 && hasNonBinary) {
    errors.push('0-1 BFS requires all edge weights to be 0 or 1. Non-binary weights found.');
  }

  if (algoId === 'bfs') {
    infos.push('BFS ignores edge weights. Distances represent hop counts (number of edges), not total weighted cost.');
  }

  if (algoId === 'floyd-warshall' && nodeCount > 12) {
    warnings.push(`Floyd-Warshall is O(V³). With ${nodeCount} nodes, this may generate many events.`);
  }

  if (algoId === 'bellman-ford') {
    const edgeListLen = graph.directed ? edgeCount : edgeCount * 2;
    if (!graph.directed && hasNegative) {
      warnings.push('Undirected graph with negative edges: a single negative edge creates a negative cycle (can traverse in both directions).');
    }
  }

  if (algoId === 'astar' && !graph.target) {
    errors.push('A* Search requires a target vertex to be selected.');
  }

  return { errors, warnings, infos };
}

function showValidation(msg, type = 'error') {
  const bar = document.getElementById('validation-messages');
  bar.textContent = msg;
  bar.className = `validation-bar is-${type}`;
  bar.classList.remove('hidden');
}

function clearValidation() {
  const bar = document.getElementById('validation-messages');
  bar.classList.add('hidden');
  bar.textContent = '';
  bar.className = 'validation-bar hidden';
}

function renderValidation(errors, warnings, infos) {
  const bar = document.getElementById('validation-messages');
  if (errors.length === 0 && warnings.length === 0 && infos.length === 0) {
    bar.classList.add('hidden');
    return;
  }
  const msgs = [...errors.map(e => '⛔ ' + e), ...warnings.map(w => '⚠ ' + w), ...infos.map(i => 'ℹ ' + i)];
  bar.innerHTML = msgs.map(m => `<span>${m}</span>`).join('<br>');
  bar.className = 'validation-bar ' + (errors.length > 0 ? 'is-error' : warnings.length > 0 ? 'is-warning' : 'is-info');
  bar.classList.remove('hidden');
}

/* ================================================================
   SECTION 5: SVG GRAPH RENDERING
================================================================ */

const svgEl = document.getElementById('graph-svg');
const svgEdges = document.getElementById('svg-edges');
const svgNodes = document.getElementById('svg-nodes');
const svgLabels = document.getElementById('svg-labels');

let svgState = {
  visitedNodes: new Set(),
  frontierNodes: new Set(),
  exploredEdges: new Set(),
  activeEdges: new Set(),
  pathNodes: new Set(),
  pathEdges: new Set(),
  currentNode: null,
  selectedNode: null,
  selectedEdge: null,
};

function renderGraph() {
  renderEdges();
  renderNodes();
  updateGraphStats();
}

function renderEdges() {
  svgEdges.innerHTML = '';
  svgLabels.innerHTML = '';
  for (const edge of graph.edges) {
    const fromNode = getNode(edge.from);
    const toNode = getNode(edge.to);
    if (!fromNode || !toNode) continue;

    const state = getEdgeState(edge.id);
    const lineEl = createEdgeSVG(edge, fromNode, toNode, state);
    svgEdges.appendChild(lineEl);

    if (document.getElementById('chk-weighted').checked) {
      const labelEl = createEdgeLabel(edge, fromNode, toNode);
      svgLabels.appendChild(labelEl);
    }
  }
}

function getEdgeMidpoint(from, to) {
  const mx = (from.x + to.x) / 2;
  const my = (from.y + to.y) / 2;
  return { x: mx, y: my };
}

function createEdgeSVG(edge, from, to, state) {
  const dx = to.x - from.x, dy = to.y - from.y;
  const dist = Math.sqrt(dx * dx + dy * dy) || 1;
  const ux = dx / dist, uy = dy / dist;
  const R = NODE_RADIUS;

  const x1 = from.x + ux * R;
  const y1 = from.y + uy * R;
  const x2 = to.x - ux * (R + (graph.directed ? 2 : 0));
  const y2 = to.y - uy * (R + (graph.directed ? 2 : 0));

  const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
  line.setAttribute('x1', x1);
  line.setAttribute('y1', y1);
  line.setAttribute('x2', x2);
  line.setAttribute('y2', y2);
  line.setAttribute('class', `edge-line state-${state}`);
  line.setAttribute('data-edge-id', edge.id);

  if (graph.directed) {
    const markerId = state === 'path' ? 'url(#arrow-path)'
      : (state === 'explored' || state === 'current') ? 'url(#arrow-explored)'
      : 'url(#arrow-default)';
    line.setAttribute('marker-end', markerId);
  }

  // Wide invisible hit-area so thin edges are easy to click
  const NS = 'http://www.w3.org/2000/svg';
  const hit = document.createElementNS(NS, 'line');
  ['x1', 'y1', 'x2', 'y2'].forEach(a => hit.setAttribute(a, line.getAttribute(a)));
  hit.setAttribute('class', 'edge-hit');
  hit.setAttribute('data-edge-id', edge.id);
  hit.addEventListener('click', onEdgeClick);
  const grp = document.createElementNS(NS, 'g');
  grp.appendChild(line);
  grp.appendChild(hit);
  return grp;
}

function createEdgeLabel(edge, from, to) {
  const mid = getEdgeMidpoint(from, to);
  const dx = to.x - from.x, dy = to.y - from.y;
  const dist = Math.sqrt(dx * dx + dy * dy) || 1;
  const nx = -dy / dist, ny = dx / dist;
  const offset = 12;

  const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
  text.setAttribute('x', mid.x + nx * offset);
  text.setAttribute('y', mid.y + ny * offset);
  text.setAttribute('class', 'edge-weight-label');
  text.setAttribute('text-anchor', 'middle');
  text.setAttribute('dominant-baseline', 'middle');
  text.textContent = edge.weight;
  text.setAttribute('data-edge-id', edge.id);
  return text;
}

function getEdgeState(edgeId) {
  if (svgState.selectedEdge === edgeId) return 'selected';
  if (svgState.pathEdges.has(edgeId)) return 'path';
  if (svgState.activeEdges && svgState.activeEdges.has(edgeId)) return 'current';
  if (svgState.exploredEdges.has(edgeId)) return 'explored';
  return 'default';
}

function getNodeState(nodeId) {
  if (svgState.selectedNode === nodeId) return 'selected';
  if (svgState.pathNodes.has(nodeId)) return 'path';
  if (svgState.currentNode === nodeId) return 'current';
  if (nodeId === graph.source) return 'source';
  if (nodeId === graph.target) return 'target';
  if (svgState.visitedNodes.has(nodeId)) return 'visited';
  if (svgState.frontierNodes.has(nodeId)) return 'frontier';
  return 'default';
}

function renderNodes() {
  svgNodes.innerHTML = '';
  for (const node of graph.nodes) {
    const state = getNodeState(node.id);
    const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    g.setAttribute('data-node-id', node.id);
    g.setAttribute('class', `node-group state-${state}`);

    const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    circle.setAttribute('cx', node.x);
    circle.setAttribute('cy', node.y);
    circle.setAttribute('r', NODE_RADIUS);
    circle.setAttribute('class', `node-circle state-${state}`);
    circle.setAttribute('data-node-id', node.id);

    const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    text.setAttribute('x', node.x);
    text.setAttribute('y', node.y);
    text.setAttribute('class', 'node-label');
    text.setAttribute('text-anchor', 'middle');
    text.setAttribute('dominant-baseline', 'middle');
    text.textContent = node.label;

    g.appendChild(circle);
    g.appendChild(text);
    g.addEventListener('mousedown', onNodeMouseDown);
    g.addEventListener('click', onNodeClick);
    svgNodes.appendChild(g);
  }
}

function applyVisualState(event, explored) {
  if (!event) {
    svgState = { visitedNodes: new Set(), frontierNodes: new Set(), exploredEdges: new Set(), activeEdges: new Set(), pathNodes: new Set(), pathEdges: new Set(), currentNode: null, selectedNode: null, selectedEdge: null };
  } else {
    svgState.visitedNodes = new Set(event.visitedNodes || []);
    svgState.frontierNodes = new Set(event.frontierNodes || []);
    svgState.exploredEdges = new Set(explored || event.exploredEdges || []);
    svgState.activeEdges = new Set(event.exploredEdges || []);
    svgState.pathNodes = new Set(event.pathNodes || []);
    svgState.pathEdges = new Set(event.pathEdges || []);
    svgState.currentNode = event.currentNode || null;
  }
  renderGraph();
}

/* ================================================================
   SECTION 6: GRAPH EDITOR INTERACTIONS
================================================================ */

let currentTool = 'addnode';
let edgeStartNode = null;
let isDragging = false;
let dragNode = null;
let dragOffset = { x: 0, y: 0 };
let pendingEdge = { from: null };

function setTool(toolName) {
  currentTool = toolName;
  edgeStartNode = null;
  pendingEdge.from = null;
  document.querySelectorAll('.tool-btn').forEach(btn => btn.classList.remove('active'));
  const btn = document.getElementById('tool-' + toolName);
  if (btn) btn.classList.add('active');
  svgState.selectedNode = null;
  svgState.selectedEdge = null;
  svgEl.setAttribute('class', `graph-svg tool-${toolName}`);
  renderGraph();
}

function getSVGPoint(e) {
  const t = e.touches ? e.touches[0] : e;
  const m = svgEl.getScreenCTM();
  if (!m) return { x: t.clientX, y: t.clientY };
  const pt = svgEl.createSVGPoint();
  pt.x = t.clientX; pt.y = t.clientY;
  return pt.matrixTransform(m.inverse());
}

function onSVGClick(e) {
  if (isDragging || didPan) return;
  if (e.target.closest('.node-group')) return;
  if (e.target.closest('.edge-line, .edge-hit')) return;
  if (currentTool === 'select' && (svgState.selectedNode || svgState.selectedEdge)) {
    svgState.selectedNode = null; svgState.selectedEdge = null; renderGraph();
  }
  if (currentTool !== 'addnode') return;

  const pt = getSVGPoint(e);
  addNode(pt.x, pt.y);
}

function onNodeClick(e) {
  e.stopPropagation();
  const nodeId = parseInt(e.currentTarget.getAttribute('data-node-id'));

  if (currentTool === 'delete') {
    removeNode(nodeId);
    return;
  }
  if (currentTool === 'addedge') {
    if (pendingEdge.from === null) {
      pendingEdge.from = nodeId;
      svgState.selectedNode = nodeId;
      renderGraph();
      showValidation(`Click a second node to create an edge from ${getNodeLabel(nodeId)}.`, 'info');
    } else {
      const from = pendingEdge.from;
      pendingEdge.from = null;
      svgState.selectedNode = null;
      clearValidation();
      showEdgeWeightPopup(from, nodeId);
    }
    return;
  }
  if (currentTool === 'select') {
    if (e.shiftKey || e.altKey) {            // Shift+click = Source, Alt+click = Target
      if (e.shiftKey) graph.source = nodeId; else graph.target = nodeId;
      invalidateResults(); populateSelectors(); renderGraph(); checkAndShowValidation();
      return;
    }
    svgState.selectedNode = nodeId;
    renderGraph();
  }
}

function onEdgeClick(e) {
  e.stopPropagation();
  const edgeId = parseInt(e.target.getAttribute('data-edge-id'));
  if (currentTool === 'delete') {
    removeEdge(edgeId);
    return;
  }
  if (currentTool === 'select') {
    svgState.selectedEdge = edgeId;
    renderGraph();
  }
}

function onEdgeDblClick(e) {
  e.stopPropagation();
  const edgeId = parseInt(e.target.getAttribute('data-edge-id'));
  openEditEdgeModal(edgeId);
}

let currentEditEdgeId = null;

function openEditEdgeModal(edgeId) {
  const edge = getEdge(edgeId);
  if (!edge) return;
  currentEditEdgeId = edgeId;
  document.getElementById('edit-edge-weight').value = edge.weight;
  openModal('modal-edit-edge');
}

// Dragging nodes
function onNodeMouseDown(e) {
  if (currentTool !== 'select') return;
  e.preventDefault();
  const nodeId = parseInt(e.currentTarget.getAttribute('data-node-id'));
  const node = getNode(nodeId);
  if (!node) return;
  isDragging = false;
  dragNode = nodeId;
  const pt = getSVGPoint(e);
  dragOffset = { x: pt.x - node.x, y: pt.y - node.y };

  function onMove(me) {
    isDragging = true;
    const p = getSVGPoint(me);
    const nd = getNode(dragNode);
    if (nd) {
      nd.x = p.x - dragOffset.x;
      nd.y = p.y - dragOffset.y;
      renderGraph();
    }
  }

  function onUp() {
    dragNode = null;
    document.removeEventListener('mousemove', onMove);
    document.removeEventListener('mouseup', onUp);
    setTimeout(() => { isDragging = false; }, 50);
  }

  document.addEventListener('mousemove', onMove);
  document.addEventListener('mouseup', onUp);
}

// Edge weight popup
let pendingEdgeNodes = null;

function showEdgeWeightPopup(from, to) {
  pendingEdgeNodes = { from, to };
  const weighted = document.getElementById('chk-weighted').checked;
  if (!weighted) {
    addEdge(from, to, 1);
    pendingEdgeNodes = null;
    return;
  }
  const defW = document.getElementById('default-weight').value;
  document.getElementById('edge-weight-input').value = defW;
  document.getElementById('edge-weight-overlay').classList.remove('hidden');
}

document.getElementById('edge-weight-confirm').addEventListener('click', () => {
  const w = parseFloat(document.getElementById('edge-weight-input').value);
  if (isNaN(w)) { showValidation('Invalid weight.', 'error'); return; }
  document.getElementById('edge-weight-overlay').classList.add('hidden');
  if (pendingEdgeNodes) {
    addEdge(pendingEdgeNodes.from, pendingEdgeNodes.to, w);
    pendingEdgeNodes = null;
  }
});

document.getElementById('edge-weight-cancel').addEventListener('click', () => {
  document.getElementById('edge-weight-overlay').classList.add('hidden');
  pendingEdgeNodes = null;
});

// Double enter in weight input
document.getElementById('edge-weight-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') document.getElementById('edge-weight-confirm').click();
  if (e.key === 'Escape') document.getElementById('edge-weight-cancel').click();
});

// Tool buttons
document.getElementById('tool-addnode').addEventListener('click', () => setTool('addnode'));
document.getElementById('tool-addedge').addEventListener('click', () => setTool('addedge'));
document.getElementById('tool-select').addEventListener('click', () => setTool('select'));
document.getElementById('tool-delete').addEventListener('click', () => setTool('delete'));

svgEl.addEventListener('click', onSVGClick);
svgEl.addEventListener('dblclick', e => {
  const el = e.target.closest('[data-edge-id]');
  if (el) openEditEdgeModal(parseInt(el.getAttribute('data-edge-id')));
});

/* ================================================================
   SECTION 7: GRAPH CONFIGURATION UI
================================================================ */

function populateSelectors() {
  const selSource = document.getElementById('sel-source');
  const selTarget = document.getElementById('sel-target');
  const fwFrom = document.getElementById('fw-from');
  const fwTo = document.getElementById('fw-to');

  [selSource, selTarget, fwFrom, fwTo].forEach(sel => {
    const prev = sel.value;
    sel.innerHTML = '';
    if (sel === selSource || sel === selTarget) {
      const none = document.createElement('option');
      none.value = '';
      none.textContent = '— none —';
      sel.appendChild(none);
    }
    for (const nd of graph.nodes) {
      const opt = document.createElement('option');
      opt.value = nd.id;
      opt.textContent = nd.label;
      sel.appendChild(opt);
    }
    if (prev && [...sel.options].some(o => o.value === prev)) sel.value = prev;
    else if (sel === fwFrom || sel === fwTo) sel.selectedIndex = sel === fwTo ? sel.options.length - 1 : 0;
  });

  selSource.value = graph.source || '';
  selTarget.value = graph.target || '';
}

document.getElementById('sel-source').addEventListener('change', e => {
  graph.source = e.target.value ? parseInt(e.target.value) : null;
  invalidateResults();
  renderGraph();
  checkAndShowValidation();
});

document.getElementById('sel-target').addEventListener('change', e => {
  graph.target = e.target.value ? parseInt(e.target.value) : null;
  invalidateResults();
  renderGraph();
  checkAndShowValidation();
});

document.getElementById('chk-directed').addEventListener('change', e => {
  graph.directed = e.target.checked;
  invalidateResults();
  renderGraph();
  checkAndShowValidation();
});

document.getElementById('chk-weighted').addEventListener('change', e => {
  invalidateResults();
  renderGraph();
  checkAndShowValidation();
});

document.getElementById('algo-select').addEventListener('change', () => {
  invalidateResults();
  updateAlgoUI();
  checkAndShowValidation();
});

document.getElementById('astar-heuristic').addEventListener('change', () => {
  invalidateResults();
});

function checkAndShowValidation() {
  const algo = document.getElementById('algo-select').value;
  const { errors, warnings, infos } = validateForAlgorithm(algo);
  renderValidation(errors, warnings, infos);
}

/* ================================================================
   SECTION 8: ALGORITHM UI METADATA
================================================================ */

function updateAlgoUI() {
  const algo = document.getElementById('algo-select').value;
  const meta = ALGO_META[algo];
  if (!meta) return;

  document.getElementById('algo-description').textContent = meta.description;
  document.getElementById('algo-complexity').innerHTML =
    `<span>Time: ${meta.timeComplexity}</span><span>Space: ${meta.spaceComplexity}</span>`;

  // Show/hide A* panel
  document.getElementById('panel-astar').classList.toggle('hidden', algo !== 'astar');
  document.getElementById('panel-distances').classList.toggle('hidden', algo === 'floyd-warshall');

  // Show/hide FW matrix panel
  document.getElementById('panel-fw-matrix').classList.toggle('hidden', algo !== 'floyd-warshall');

  // Show/hide A* scores
  document.getElementById('panel-astar-scores').classList.toggle('hidden', algo !== 'astar');

  // Show/hide queue panel
  document.getElementById('panel-queue').classList.toggle('hidden', algo !== 'bfs' && algo !== '01bfs');

  if (algo === '01bfs') {
    document.getElementById('queue-panel-title').textContent = 'Deque Contents';
  } else {
    document.getElementById('queue-panel-title').textContent = 'Queue Contents';
  }

  updateAlgoInfo(meta, algo);
  updatePseudocode(algo, null);
}

function updateAlgoInfo(meta, algo) {
  const div = document.getElementById('algo-info-display');
  div.innerHTML = `
    <h3>Purpose</h3>
    <p>${meta.description}</p>
    <h3>Graph Requirements</h3>
    <ul>
      ${meta.requiresDirected ? '<li>Directed graph required</li>' : '<li>Directed or undirected</li>'}
      ${meta.requiresNonNegative ? '<li>Non-negative edge weights only</li>' : ''}
      ${meta.allowsNegative ? '<li>Negative edge weights supported</li>' : ''}
      ${meta.requires01 ? '<li>Edge weights must be 0 or 1</li>' : ''}
      ${meta.requiresDAG ? '<li>Must be acyclic (DAG)</li>' : ''}
      ${meta.requiresSource ? '<li>Source vertex required</li>' : ''}
      ${meta.requiresTarget ? '<li>Target vertex required</li>' : ''}
    </ul>
    <h3>Complexity</h3>
    <p><span class="tag">Time: ${meta.timeComplexity}</span> <span class="tag">Space: ${meta.spaceComplexity}</span></p>
    <h3>Use Cases</h3>
    <ul>${meta.useCases.map(u => `<li>${u}</li>`).join('')}</ul>
    <h3>Limitations</h3>
    <ul>${meta.limitations.map(l => `<li>${l}</li>`).join('')}</ul>
  `;
}

function updatePseudocode(algo, activeLine) {
  const lines = PSEUDOCODE[algo] || [];
  const pre = document.getElementById('pseudocode-display');
  pre.innerHTML = lines.map((line, i) => {
    const isActive = activeLine && activeLine.includes(i);
    return `<span class="pc-line${isActive ? ' active' : ''}">${escapeHtml(line)}</span>`;
  }).join('\n');
}

function escapeHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/* ================================================================
   SECTION 9: PLAYBACK ENGINE
================================================================ */

let execResult = null;
let currentEventIndex = -1;
let playTimer = null;
let isPlaying = false;

function invalidateResults() {
  execResult = null;
  currentEventIndex = -1;
  stopPlayback();
  fwResult = null;
  const fwc = document.getElementById('fw-matrix-container');
  if (fwc) fwc.innerHTML = '';
  updatePlaybackUI();
  resetVisualState();
  document.getElementById('step-badge').textContent = 'Ready';
  document.getElementById('step-title').textContent = 'Select an algorithm and click Run';
  document.getElementById('step-description').textContent = 'Build your graph, configure the algorithm, then click Run.';
  document.getElementById('result-display').innerHTML = '<p class="result-placeholder">Run an algorithm to see results.</p>';
  clearDistanceTable();
}

function resetVisualState() {
  svgState.visitedNodes = new Set();
  svgState.frontierNodes = new Set();
  svgState.exploredEdges = new Set();
  svgState.activeEdges = new Set();
  svgState.pathNodes = new Set();
  svgState.pathEdges = new Set();
  svgState.currentNode = null;
  renderGraph();
}

function getPlaybackSpeed() {
  const val = parseInt(document.getElementById('speed-slider').value);
  // 1 = 2000ms, 10 = 100ms
  return Math.round(2200 - val * 200);
}

function runAlgorithm() {
  stopPlayback();

  const algo = document.getElementById('algo-select').value;
  const { errors, warnings, infos } = validateForAlgorithm(algo);
  if (errors.length > 0) invalidateResults();
  renderValidation(errors, warnings, infos);
  if (errors.length > 0) return;

  const g = cloneGraph(graph);
  if (!isWeighted()) g.edges.forEach(e => { e.weight = 1; });
  const src = graph.source;
  const tgt = graph.target;
  const heuristic = document.getElementById('astar-heuristic').value;

  let result;
  try {
    if (algo === 'dijkstra') result = runDijkstra(g, src, tgt);
    else if (algo === 'bellman-ford') result = runBellmanFord(g, src, tgt);
    else if (algo === 'bfs') result = runBFS(g, src, tgt);
    else if (algo === 'floyd-warshall') result = runFloydWarshall(g);
    else if (algo === 'astar') result = runAStar(g, src, tgt, heuristic);
    else if (algo === 'dag') result = runDAG(g, src, tgt);
    else if (algo === '01bfs') result = run01BFS(g, src, tgt);
    else return;
  } catch (err) {
    showValidation(`Algorithm error: ${err.message}`, 'error');
    return;
  }

  if (!result || !result.events) {
    showValidation('Algorithm returned no result.', 'error');
    return;
  }

  execResult = { ...result, algo, g };
  currentEventIndex = -1;
  updatePlaybackUI();
  showResult(result, algo, g);

  // Step to first event
  stepForward();
}

function stepForward() {
  if (!execResult || !execResult.events) return;
  if (currentEventIndex >= execResult.events.length - 1) {
    if (isPlaying) stopPlayback();
    return;
  }
  currentEventIndex++;
  applyEvent(currentEventIndex);
  updatePlaybackUI();
  updateStepCounter();
}

function stepBackward() {
  if (!execResult || currentEventIndex <= 0) return;
  currentEventIndex--;
  applyEvent(currentEventIndex);
  updatePlaybackUI();
  updateStepCounter();
}

function applyEvent(idx) {
  const event = execResult.events[idx];
  if (!event) return;

  const explored = new Set();
  for (let i = 0; i <= idx; i++) (execResult.events[i].exploredEdges || []).forEach(id => explored.add(id));
  applyVisualState(event, explored);
  updateStepPanel(event);
  updateDistanceTable(event);
  updatePseudocode(execResult.algo, event.pseudocodeLine);
  updateAlgorithmSpecificPanels(event, execResult.algo, execResult.g);
}

function startPlayback() {
  if (!execResult || currentEventIndex >= execResult.events.length - 1) return;
  isPlaying = true;
  document.getElementById('play-icon').classList.add('hidden');
  document.getElementById('pause-icon').classList.remove('hidden');
  document.getElementById('btn-play').classList.add('is-paused');
  scheduleNext();
}

function stopPlayback() {
  isPlaying = false;
  if (playTimer) { clearTimeout(playTimer); playTimer = null; }
  document.getElementById('play-icon').classList.remove('hidden');
  document.getElementById('pause-icon').classList.add('hidden');
  document.getElementById('btn-play').classList.remove('is-paused');
}

function scheduleNext() {
  if (!isPlaying) return;
  const speed = getPlaybackSpeed();
  playTimer = setTimeout(() => {
    if (!isPlaying) return;
    stepForward();
    if (currentEventIndex < execResult.events.length - 1) {
      scheduleNext();
    } else {
      stopPlayback();
    }
  }, speed);
}

function togglePlay() {
  if (!execResult) return;
  if (isPlaying) {
    stopPlayback();
  } else {
    if (currentEventIndex >= execResult.events.length - 1) {
      // Restart
      currentEventIndex = -1;
      resetVisualState();
    }
    startPlayback();
  }
}

function resetPlayback() {
  stopPlayback();
  currentEventIndex = -1;
  resetVisualState();
  if (execResult) {
    updatePlaybackUI();
    updateStepCounter();
    updatePseudocode(execResult.algo, null);
    clearDistanceTable();
    document.getElementById('step-badge').textContent = 'Ready';
    document.getElementById('step-title').textContent = 'Click Play or Next Step';
    document.getElementById('step-description').textContent = 'Visualization has been reset. Click Play or Next Step to begin.';
  }
}

function updatePlaybackUI() {
  const hasResult = !!execResult;
  const atStart = currentEventIndex <= -1;
  const atEnd = hasResult && execResult.events && currentEventIndex >= execResult.events.length - 1;

  document.getElementById('btn-play').disabled = !hasResult;
  document.getElementById('btn-next').disabled = !hasResult || atEnd;
  document.getElementById('btn-prev').disabled = !hasResult || atStart;
}

function updateStepCounter() {
  if (!execResult || !execResult.events) {
    document.getElementById('step-counter').textContent = 'Step — / —';
    return;
  }
  const total = execResult.events.length;
  const cur = currentEventIndex + 1;
  document.getElementById('step-counter').textContent = `Step ${cur} / ${total}`;
}

function updateStepPanel(event) {
  const badge = document.getElementById('step-badge');
  const title = document.getElementById('step-title');
  const desc = document.getElementById('step-description');

  const badgeClass = {
    init: 'badge-init',
    select: 'badge-explore',
    examine: 'badge-explore',
    relax: 'badge-relax',
    done: 'badge-done',
    error: 'badge-error',
    'neg-cycle': 'badge-error',
    'early-exit': 'badge-done',
    path: 'badge-path',
  };

  badge.textContent = event.badge || event.type;
  badge.className = 'step-badge ' + (badgeClass[event.badge] || badgeClass[event.type] || '');
  title.textContent = event.title || '';
  desc.textContent = event.description || '';
}

/* ================================================================
   SECTION 10: RESULT PANEL & DISTANCE TABLE
================================================================ */

function showResult(result, algo, g) {
  const div = document.getElementById('result-display');

  if (result.status === 'error') {
    div.innerHTML = `<div class="result-unreachable">⛔ ${escapeHtml(result.error || 'Algorithm error.')}</div>`;
    return;
  }

  if (result.status === 'neg-cycle') {
    if (algo === 'floyd-warshall') renderFWMatrix(result, g);
    div.innerHTML = `<div class="result-neg-cycle">🔴 Negative cycle detected!<br>Shortest path distances are undefined for vertices reachable through the cycle.</div>`;
    return;
  }

  if (algo === 'floyd-warshall') {
    renderFWMatrix(result, g);
    div.innerHTML = `<p style="color:var(--color-green);font-size:.8rem">All-pairs shortest paths computed. Use the matrix panel to explore routes.</p>`;
    return;
  }

  const src = graph.source;
  const tgt = graph.target;
  let html = '';

  if (result.path && result.path.length > 0) {
    const pathLabels = result.path.map(id => getNodeLabelFromG(g, id));
    const isBFS = algo === 'bfs';
    const costLabel = isBFS ? 'Hops' : 'Cost';
    const costVal = result.cost;
    html += `<div class="result-path">${pathLabels.join(' → ')}</div>`;
    html += `<div class="result-cost"><span class="cost-label">${costLabel}: </span><span class="cost-value">${distStr(costVal)}</span></div>`;
    if (isBFS) html += `<p style="font-size:.7rem;color:var(--text-muted)">Note: BFS counts hops (edges), not total weight.</p>`;
  } else if (result.status === 'unreachable') {
    html += `<div class="result-unreachable">⛔ Destination unreachable from source.</div>`;
  } else if (!tgt) {
    html += `<p style="color:var(--text-secondary);font-size:.8rem">No target selected. Distances shown in table.</p>`;
  }

  div.innerHTML = html || `<p class="result-placeholder">Algorithm complete. See distance table.</p>`;
}

function clearDistanceTable() {
  document.getElementById('distance-table-body').innerHTML = '';
  document.getElementById('astar-score-body').innerHTML = '';
  document.getElementById('queue-display').innerHTML = '';
  const topo = document.getElementById('topo-order-display');
  if (topo) topo.remove();
}

function updateDistanceTable(event) {
  if (!execResult || !execResult.g) return;
  const g = execResult.g;
  const tbody = document.getElementById('distance-table-body');
  const dist = event.distances || {};
  const prev = event.predecessors || {};

  tbody.innerHTML = '';
  for (const nd of g.nodes) {
    const id = nd.id;
    const d = dist[id];
    const p = prev[id];
    const rowClass = id === event.currentNode ? 'row-current'
      : event.pathNodes && event.pathNodes.includes(id) ? 'row-path'
      : event.visitedNodes && event.visitedNodes.includes(id) ? 'row-visited'
      : id === g.source ? 'row-source' : '';
    const tr = document.createElement('tr');
    if (rowClass) tr.className = rowClass;
    tr.innerHTML = `<td>${escapeHtml(nd.label)}</td><td>${escapeHtml(distStr(d))}</td><td>${p !== null && p !== undefined ? escapeHtml(getNodeLabelFromG(g, p)) : '—'}</td>`;
    tbody.appendChild(tr);
  }
}

function updateAlgorithmSpecificPanels(event, algo, g) {
  const state = event.algorithmSpecificState || {};

  // A* score table
  if (algo === 'astar') {
    const tbody = document.getElementById('astar-score-body');
    tbody.innerHTML = '';
    const gScore = state.gScore || {};
    const hScore = state.hScore || {};
    const fScore = state.fScore || {};
    const open = state.open || new Set();
    const closed = state.closed || new Set();
    for (const nd of g.nodes) {
      const id = nd.id;
      const stateClass = id === event.currentNode ? 'astar-state-current'
        : open.has(id) ? 'astar-state-open'
        : closed.has(id) ? 'astar-state-closed' : '';
      const stateLabel = id === event.currentNode ? 'current'
        : open.has(id) ? 'open'
        : closed.has(id) ? 'closed' : '';
      const tr = document.createElement('tr');
      if (stateClass) tr.className = stateClass;
      tr.innerHTML = `<td>${escapeHtml(nd.label)}</td><td>${escapeHtml(distStr(gScore[id]))}</td><td>${(hScore[id] !== undefined ? hScore[id].toFixed(2) : '—')}</td><td>${(fScore[id] !== undefined && fScore[id] !== INFINITY ? fScore[id].toFixed(2) : '∞')}</td><td>${stateLabel}</td>`;
      tbody.appendChild(tr);
    }
  }

  // Queue panel
  if (algo === 'bfs' || algo === '01bfs') {
    const qDiv = document.getElementById('queue-display');
    const deque = state.deque || state.queue || [];
    qDiv.innerHTML = '';
    if (deque.length === 0) {
      qDiv.innerHTML = '<span style="color:var(--text-muted);font-size:.75rem">empty</span>';
    } else {
      deque.forEach((id, i) => {
        const item = document.createElement('div');
        item.className = 'queue-item' + (i === 0 ? ' front' : '');
        const label = document.createElement('span');
        label.textContent = getNodeLabelFromG(g, id);
        item.appendChild(label);
        const dist = event.distances && event.distances[id] !== undefined
          ? document.createElement('span') : null;
        if (dist) {
          dist.className = 'queue-dist';
          dist.textContent = distStr(event.distances[id]);
          item.appendChild(dist);
        }
        qDiv.appendChild(item);
      });
    }
  }

  // DAG topo display (inject below table if exists)
  if (algo === 'dag' && state.topoOrder) {
    let topoDiv = document.getElementById('topo-order-display');
    if (!topoDiv) {
      topoDiv = document.createElement('div');
      topoDiv.id = 'topo-order-display';
      topoDiv.className = 'topo-display';
      document.getElementById('distance-table-container').after(topoDiv);
    }
    topoDiv.innerHTML = state.topoOrder.map((id, i) => {
      const cls = i === state.topoPos ? 'topo-node topo-current'
        : (state.topoPos !== undefined && i < state.topoPos) ? 'topo-node topo-done'
        : 'topo-node';
      return `<span class="${cls}">${escapeHtml(getNodeLabelFromG(g, id))}</span>${i < state.topoOrder.length - 1 ? '<span class="topo-arrow">→</span>' : ''}`;
    }).join('');
  }

  // FW matrix highlight
  if (algo === 'floyd-warshall' && state.matrix) {
    renderFWMatrixState(state, g);
  }
}

/* ================================================================
   SECTION 11: FLOYD-WARSHALL MATRIX UI
================================================================ */

let fwResult = null;

function renderFWMatrix(result, g) {
  fwResult = result;
  const container = document.getElementById('fw-matrix-container');
  const { matrix: D, ids } = result;
  const n = ids.length;

  let html = '<table class="fw-matrix-table"><thead><tr><th>\\</th>';
  for (const id of ids) html += `<th>${escapeHtml(getNodeLabelFromG(g, id))}</th>`;
  html += '</tr></thead><tbody>';

  for (let i = 0; i < n; i++) {
    html += `<tr><th>${escapeHtml(getNodeLabelFromG(g, ids[i]))}</th>`;
    for (let j = 0; j < n; j++) {
      const val = D[i][j];
      const cls = val === INFINITY ? 'fw-inf' : (i === j && val < 0 ? 'fw-neg-cycle' : '');
      html += `<td class="${cls}" data-i="${i}" data-j="${j}">${val === INFINITY ? '∞' : val}</td>`;
    }
    html += '</tr>';
  }
  html += '</tbody></table>';
  container.innerHTML = html;
}

function renderFWMatrixState(state, g) {
  const D = state.matrix, ids = state.ids;
  if (!D || !ids) return;
  const k = state.k;
  let html = '<table class="fw-matrix-table"><thead><tr><th>\\</th>' +
    ids.map(id => `<th>${escapeHtml(getNodeLabelFromG(g, id))}</th>`).join('') + '</tr></thead><tbody>';
  D.forEach((row, i) => {
    html += `<tr><th>${escapeHtml(getNodeLabelFromG(g, ids[i]))}</th>`;
    row.forEach((val, j) => {
      const cls = [];
      if (val === INFINITY) cls.push('fw-inf');
      if (i === j && val < 0) cls.push('fw-neg-cycle');
      if (k !== undefined && k !== null && (i === k || j === k)) cls.push('fw-highlighted');
      if (state.i === i && state.j === j) cls.push('fw-updated');
      html += `<td class="${cls.join(' ')}" data-i="${i}" data-j="${j}">${distStr(val)}</td>`;
    });
    html += '</tr>';
  });
  document.getElementById('fw-matrix-container').innerHTML = html + '</tbody></table>';
}

function updateFWMatrixHighlight(state) {
  const table = document.querySelector('.fw-matrix-table');
  if (!table || !state) return;
  table.querySelectorAll('td').forEach(td => {
    td.classList.remove('fw-highlighted');
    if (state.k !== undefined && state.k !== null) {
      const i = parseInt(td.dataset.i);
      const j = parseInt(td.dataset.j);
      if (i === state.k || j === state.k) td.classList.add('fw-highlighted');
    }
  });
}

document.getElementById('fw-show-path').addEventListener('click', () => {
  if (!fwResult) return;
  const fromSel = document.getElementById('fw-from');
  const toSel = document.getElementById('fw-to');
  const fromId = parseInt(fromSel.value);
  const toId = parseInt(toSel.value);
  if (isNaN(fromId) || isNaN(toId)) return;

  const { idx, nxt, matrix: D, ids } = fwResult;
  const si = idx[fromId], ti = idx[toId];
  if (si === undefined || ti === undefined) return;

  const pathIdx = reconstructFWPath(nxt, si, ti);
  if (!pathIdx || D[si][ti] === INFINITY) {
    showValidation('No path between selected vertices.', 'warning');
    return;
  }

  const pathIds = pathIdx.map(i => ids[i]);
  svgState.pathNodes = new Set(pathIds);
  svgState.pathEdges = new Set(getPathEdges(graph, pathIds));
  renderGraph();

  // Highlight in matrix
  const table = document.querySelector('.fw-matrix-table');
  if (table) {
    table.querySelectorAll('td').forEach(td => td.classList.remove('fw-path'));
    const cell = table.querySelector(`td[data-i="${si}"][data-j="${ti}"]`);
    if (cell) cell.classList.add('fw-path');
  }
});

/* ================================================================
   SECTION 12: GRAPH STATISTICS
================================================================ */

function updateGraphStats() {
  const statsDiv = document.getElementById('graph-stats');
  const V = graph.nodes.length;
  const E = graph.edges.length;
  const hasNeg = graph.edges.some(e => e.weight < 0);
  const hasZero = graph.edges.some(e => e.weight === 0);
  const density = V > 1 ? (E / (V * (V - 1))).toFixed(2) : '—';

  statsDiv.innerHTML = `
    <div class="stat-item"><div class="stat-label">Vertices</div><div class="stat-value">${V}</div></div>
    <div class="stat-item"><div class="stat-label">Edges</div><div class="stat-value">${E}</div></div>
    <div class="stat-item"><div class="stat-label">Type</div><div class="stat-value" style="font-size:.7rem">${graph.directed ? 'Directed' : 'Undirected'}</div></div>
    <div class="stat-item"><div class="stat-label">Density</div><div class="stat-value">${density}</div></div>
    ${hasNeg ? '<div class="stat-item" style="grid-column:span 2"><div class="stat-label" style="color:var(--color-red)">Negative edges present</div></div>' : ''}
  `;
}

/* ================================================================
   SECTION 13: MODAL SYSTEM
================================================================ */

function openModal(id) {
  document.getElementById(id).classList.remove('hidden');
  document.getElementById('modal-backdrop').classList.remove('hidden');
}

function closeModal(id) {
  document.getElementById(id).classList.add('hidden');
  document.getElementById('modal-backdrop').classList.add('hidden');
}

document.getElementById('close-modal-tests').addEventListener('click', () => closeModal('modal-tests'));
document.getElementById('close-modal-edit-edge').addEventListener('click', () => closeModal('modal-edit-edge'));
document.getElementById('modal-backdrop').addEventListener('click', () => {
  closeModal('modal-tests');
  closeModal('modal-edit-edge');
});

['modal-tests', 'modal-edit-edge'].forEach(id =>
  document.getElementById(id).addEventListener('click', e => { if (e.target.id === id) closeModal(id); }));
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { closeModal('modal-tests'); closeModal('modal-edit-edge'); }
});

document.getElementById('btn-save-edge').addEventListener('click', () => {
  if (currentEditEdgeId === null) return;
  const w = parseFloat(document.getElementById('edit-edge-weight').value);
  if (isNaN(w)) return;
  updateEdgeWeight(currentEditEdgeId, w);
  closeModal('modal-edit-edge');
  currentEditEdgeId = null;
});

document.getElementById('btn-delete-edge-modal').addEventListener('click', () => {
  if (currentEditEdgeId === null) return;
  removeEdge(currentEditEdgeId);
  closeModal('modal-edit-edge');
  currentEditEdgeId = null;
});

/* ================================================================
   SECTION 14: IMPORT / EXPORT
================================================================ */

document.getElementById('btn-export').addEventListener('click', () => {
  const data = JSON.stringify({ ...graph, exportedAt: new Date().toISOString() }, null, 2);
  const blob = new Blob([data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'pathpilot-graph.json';
  a.click();
  URL.revokeObjectURL(url);
});

document.getElementById('btn-import').addEventListener('click', () => {
  document.getElementById('file-input').click();
});

document.getElementById('file-input').addEventListener('change', e => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = ev => {
    try {
      const data = JSON.parse(ev.target.result);
      importGraph(data);
    } catch (err) {
      showValidation('Import failed: invalid JSON. ' + err.message, 'error');
    }
  };
  reader.readAsText(file);
  e.target.value = '';
});

function importGraph(data) {
  // Validate structure
  if (!Array.isArray(data.nodes) || !Array.isArray(data.edges)) {
    showValidation('Import failed: JSON must have "nodes" and "edges" arrays.', 'error');
    return;
  }
  const nodeIds = new Set(data.nodes.map(n => n.id));
  if (nodeIds.size !== data.nodes.length) {
    showValidation('Import failed: node IDs must be unique.', 'error');
    return;
  }
  for (const e of data.edges) {
    if (!nodeIds.has(e.from) || !nodeIds.has(e.to)) {
      showValidation('Import failed: edge references non-existent node id.', 'error');
      return;
    }
    if (typeof e.weight !== 'number' || !isFinite(e.weight)) {
      showValidation('Import failed: edge weight must be a finite number.', 'error');
      return;
    }
  }

  graph.nodes = data.nodes.map(n => ({ id: n.id, label: String(n.label), x: Number(n.x), y: Number(n.y) }));
  graph.edges = data.edges.map(e => ({ id: e.id, from: e.from, to: e.to, weight: Number(e.weight) }));
  graph.directed = !!data.directed;
  graph.source = data.source || null;
  graph.target = data.target || null;

  nextNodeId = Math.max(...graph.nodes.map(n => n.id), 0) + 1;
  nextEdgeId = Math.max(...graph.edges.map(e => e.id), 0) + 1;

  document.getElementById('chk-directed').checked = graph.directed;
  invalidateResults();
  updateAll();
  fitView();
  showValidation('Graph imported successfully.', 'info');
  setTimeout(clearValidation, 3000);
}

/* ================================================================
   SECTION 15: EXAMPLE GRAPHS
================================================================ */

const EXAMPLE_GRAPHS = {
  nonneg: {
    directed: false,
    nodes: [
      { id: 1, label: 'A', x: 100, y: 200 },
      { id: 2, label: 'B', x: 250, y: 100 },
      { id: 3, label: 'C', x: 250, y: 300 },
      { id: 4, label: 'D', x: 400, y: 200 },
      { id: 5, label: 'E', x: 400, y: 350 },
      { id: 6, label: 'F', x: 550, y: 250 },
    ],
    edges: [
      { id: 1, from: 1, to: 2, weight: 4 },
      { id: 2, from: 1, to: 3, weight: 2 },
      { id: 3, from: 2, to: 3, weight: 1 },
      { id: 4, from: 2, to: 4, weight: 5 },
      { id: 5, from: 3, to: 4, weight: 8 },
      { id: 6, from: 3, to: 5, weight: 10 },
      { id: 7, from: 4, to: 5, weight: 2 },
      { id: 8, from: 4, to: 6, weight: 6 },
      { id: 9, from: 5, to: 6, weight: 3 },
    ],
    source: 1, target: 6,
  },
  negEdge: {
    directed: true,
    nodes: [
      { id: 1, label: 'A', x: 80, y: 200 },
      { id: 2, label: 'B', x: 230, y: 120 },
      { id: 3, label: 'C', x: 380, y: 200 },
      { id: 4, label: 'D', x: 540, y: 200 },
    ],
    edges: [
      { id: 1, from: 1, to: 2, weight: 4 },
      { id: 2, from: 1, to: 3, weight: 5 },
      { id: 3, from: 2, to: 3, weight: -2 },
      { id: 4, from: 3, to: 4, weight: 3 },
      { id: 5, from: 2, to: 4, weight: 6 },
    ],
    source: 1, target: 4,
  },
  negCycle: {
    directed: true,
    nodes: [
      { id: 1, label: 'A', x: 200, y: 100 },
      { id: 2, label: 'B', x: 350, y: 300 },
      { id: 3, label: 'C', x: 80, y: 300 },
    ],
    edges: [
      { id: 1, from: 1, to: 2, weight: 1 },
      { id: 2, from: 2, to: 3, weight: -3 },
      { id: 3, from: 3, to: 1, weight: 1 },
    ],
    source: 1, target: 2,
  },
  unreach: {
    directed: true,
    nodes: [
      { id: 1, label: 'A', x: 100, y: 200 },
      { id: 2, label: 'B', x: 250, y: 200 },
      { id: 3, label: 'C', x: 400, y: 200 },
      { id: 4, label: 'D', x: 550, y: 200 },
    ],
    edges: [
      { id: 1, from: 1, to: 2, weight: 2 },
      { id: 2, from: 3, to: 4, weight: 1 },
    ],
    source: 1, target: 4,
  },
  zeroOne: {
    directed: true,
    nodes: [
      { id: 1, label: 'A', x: 80, y: 200 },
      { id: 2, label: 'B', x: 280, y: 120 },
      { id: 3, label: 'C', x: 280, y: 280 },
      { id: 4, label: 'D', x: 480, y: 200 },
    ],
    edges: [
      { id: 1, from: 1, to: 2, weight: 1 },
      { id: 2, from: 1, to: 3, weight: 0 },
      { id: 3, from: 3, to: 2, weight: 0 },
      { id: 4, from: 2, to: 4, weight: 1 },
      { id: 5, from: 3, to: 4, weight: 1 },
    ],
    source: 1, target: 2,
  },
  dag: {
    directed: true,
    nodes: [
      { id: 1, label: 'A', x: 80, y: 200 },
      { id: 2, label: 'B', x: 250, y: 120 },
      { id: 3, label: 'C', x: 250, y: 280 },
      { id: 4, label: 'D', x: 430, y: 200 },
    ],
    edges: [
      { id: 1, from: 1, to: 2, weight: 3 },
      { id: 2, from: 1, to: 3, weight: 6 },
      { id: 3, from: 2, to: 3, weight: -2 },
      { id: 4, from: 2, to: 4, weight: 4 },
      { id: 5, from: 3, to: 4, weight: 2 },
    ],
    source: 1, target: 4,
  },
  invalidDag: {
    directed: true,
    nodes: [
      { id: 1, label: 'A', x: 200, y: 100 },
      { id: 2, label: 'B', x: 350, y: 280 },
      { id: 3, label: 'C', x: 80, y: 280 },
    ],
    edges: [
      { id: 1, from: 1, to: 2, weight: 2 },
      { id: 2, from: 2, to: 3, weight: 3 },
      { id: 3, from: 3, to: 1, weight: 1 },
    ],
    source: 1, target: 2,
  },
  astar: {
    directed: false,
    nodes: [
      { id: 1, label: 'S', x: 80, y: 200 },
      { id: 2, label: 'A', x: 220, y: 100 },
      { id: 3, label: 'B', x: 220, y: 300 },
      { id: 4, label: 'C', x: 370, y: 100 },
      { id: 5, label: 'T', x: 500, y: 200 },
    ],
    edges: [
      { id: 1, from: 1, to: 2, weight: 1 },
      { id: 2, from: 1, to: 3, weight: 4 },
      { id: 3, from: 2, to: 4, weight: 2 },
      { id: 4, from: 3, to: 5, weight: 5 },
      { id: 5, from: 4, to: 5, weight: 1 },
    ],
    source: 1, target: 5,
  },
};

function loadExample(name) {
  const ex = EXAMPLE_GRAPHS[name];
  if (!ex) return;
  const data = JSON.parse(JSON.stringify(ex));
  graph.nodes = data.nodes;
  graph.edges = data.edges;
  graph.directed = data.directed;
  graph.source = data.source || null;
  graph.target = data.target || null;
  nextNodeId = Math.max(...graph.nodes.map(n => n.id), 0) + 1;
  nextEdgeId = Math.max(...graph.edges.map(e => e.id), 0) + 1;
  document.getElementById('chk-directed').checked = graph.directed;
  invalidateResults();
  updateAll();
}

document.querySelectorAll('.example-btn').forEach(btn => {
  btn.addEventListener('click', () => loadExample(btn.dataset.example));
});

/* ================================================================
   SECTION 16: RANDOM GRAPH GENERATOR
================================================================ */

document.getElementById('btn-random').addEventListener('click', () => {
  const V = parseInt(document.getElementById('rand-nodes').value) || 6;
  const E = parseInt(document.getElementById('rand-edges').value) || 8;
  generateRandom(Math.min(V, MAX_NODES), E);
});

function generateRandom(V, E) {
  const algo = document.getElementById('algo-select').value;
  if (algo === 'dag' && !graph.directed) {
    graph.directed = true;
    document.getElementById('chk-directed').checked = true;
  }
  const directed = graph.directed;
  // Acyclic orientation (low index -> high index) keeps negative weights free of negative cycles
  const acyclic = algo === 'dag' || (directed && (algo === 'bellman-ford' || algo === 'floyd-warshall'));
  const is01 = algo === '01bfs';
  resetView();
  const W = svgEl.clientWidth || 700, H = svgEl.clientHeight || 450;
  E = Math.min(Math.max(E, V - 1), V * (V - 1) / 2);

  graph.nodes = []; graph.edges = [];
  nextNodeId = 1; nextEdgeId = 1;
  for (let i = 0; i < V; i++) {
    let x, y, tries = 0;
    do { x = 60 + Math.random() * (W - 120); y = 60 + Math.random() * (H - 120); tries++; }
    while (tries < 40 && graph.nodes.some(n => Math.hypot(n.x - x, n.y - y) < 70));
    graph.nodes.push({ id: nextNodeId++, label: generateLabel(i), x, y });
  }
  const added = new Set();
  const weight = () => is01 ? Math.round(Math.random()) : acyclic ? Math.floor(Math.random() * 10) - 2 : Math.floor(Math.random() * 9) + 1;
  const add = (a, b) => {
    if (acyclic && a > b) [a, b] = [b, a];
    const key = `${Math.min(a, b)}-${Math.max(a, b)}`;
    if (a === b || added.has(key)) return;
    added.add(key);
    graph.edges.push({ id: nextEdgeId++, from: graph.nodes[a].id, to: graph.nodes[b].id, weight: weight() });
  };
  for (let i = 1; i < V; i++) add(Math.floor(Math.random() * i), i);   // guarantees A reaches every node
  let tries = 0;
  while (graph.edges.length < E && tries++ < E * 30) add(Math.floor(Math.random() * V), Math.floor(Math.random() * V));

  graph.source = graph.nodes[0].id;
  graph.target = graph.nodes[V - 1].id;
  invalidateResults();
  updateAll();
  fitView();
}

/* ================================================================
   SECTION 17: FIT VIEW
================================================================ */

document.getElementById('btn-fit').addEventListener('click', fitView);

/* Zoom & pan use the SVG viewBox, so node coordinates are never modified. */
const ZOOM_MIN = 0.2, ZOOM_MAX = 5;
let view = { x: 0, y: 0, w: 800, h: 500 };
let didPan = false;

function canvasSize() { return { W: svgEl.clientWidth || 800, H: svgEl.clientHeight || 500 }; }
function currentZoom() { return canvasSize().W / view.w; }

function applyView() {
  svgEl.setAttribute('viewBox', `${view.x} ${view.y} ${view.w} ${view.h}`);
  const lbl = document.getElementById('zoom-label');
  if (lbl) lbl.textContent = Math.round(currentZoom() * 100) + '%';
}

function setZoom(z, cx, cy) {
  const { W, H } = canvasSize();
  z = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, z));
  if (cx === undefined) { cx = view.x + view.w / 2; cy = view.y + view.h / 2; }
  const fx = (cx - view.x) / view.w, fy = (cy - view.y) / view.h;
  view.w = W / z; view.h = H / z;
  view.x = cx - fx * view.w; view.y = cy - fy * view.h;
  applyView();
}
function zoomBy(f, cx, cy) { setZoom(currentZoom() * f, cx, cy); }
function resetView() { const { W, H } = canvasSize(); view = { x: 0, y: 0, w: W, h: H }; applyView(); }

function fitView() {
  if (graph.nodes.length === 0) { resetView(); return; }
  const { W, H } = canvasSize();
  const pad = 70, R = NODE_RADIUS;
  const minX = Math.min(...graph.nodes.map(n => n.x)) - R, maxX = Math.max(...graph.nodes.map(n => n.x)) + R;
  const minY = Math.min(...graph.nodes.map(n => n.y)) - R, maxY = Math.max(...graph.nodes.map(n => n.y)) + R;
  const z = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, Math.min((W - 2 * pad) / (maxX - minX), (H - 2 * pad) / (maxY - minY), 1.5)));
  view.w = W / z; view.h = H / z;
  view.x = (minX + maxX) / 2 - view.w / 2;
  view.y = (minY + maxY) / 2 - view.h / 2;
  applyView();
}

document.getElementById('zoom-in').addEventListener('click', () => zoomBy(1.25));
document.getElementById('zoom-out').addEventListener('click', () => zoomBy(1 / 1.25));
document.getElementById('zoom-reset').addEventListener('click', () => setZoom(1));
document.getElementById('zoom-fit').addEventListener('click', fitView);

svgEl.addEventListener('wheel', e => {
  e.preventDefault();
  const p = getSVGPoint(e);
  zoomBy(e.deltaY < 0 ? 1.12 : 1 / 1.12, p.x, p.y);
}, { passive: false });

// Pan: drag empty canvas (Select tool), or middle-mouse / Shift+drag in any tool
svgEl.addEventListener('mousedown', e => {
  if (e.target.closest('.node-group, .edge-hit')) return;
  if (!(currentTool === 'select' || e.button === 1 || e.shiftKey)) return;
  e.preventDefault();
  const sx = e.clientX, sy = e.clientY, ox = view.x, oy = view.y;
  const k = view.w / canvasSize().W;
  let moved = false;
  const mv = me => {
    const dx = me.clientX - sx, dy = me.clientY - sy;
    if (!moved && Math.hypot(dx, dy) < 4) return;
    moved = true; didPan = true;
    view.x = ox - dx * k; view.y = oy - dy * k;
    applyView();
  };
  const up = () => {
    document.removeEventListener('mousemove', mv);
    document.removeEventListener('mouseup', up);
    setTimeout(() => { didPan = false; }, 50);
  };
  document.addEventListener('mousemove', mv);
  document.addEventListener('mouseup', up);
});

if (typeof ResizeObserver !== 'undefined') {
  new ResizeObserver(() => { const { W, H } = canvasSize(); view.h = view.w * H / W; applyView(); }).observe(svgEl);
}

/* ================================================================
   SECTION 18: PLAYBACK CONTROLS
================================================================ */

document.getElementById('btn-run').addEventListener('click', runAlgorithm);
document.getElementById('btn-play').addEventListener('click', togglePlay);
document.getElementById('btn-next').addEventListener('click', stepForward);
document.getElementById('btn-prev').addEventListener('click', stepBackward);
document.getElementById('btn-reset').addEventListener('click', resetPlayback);
document.getElementById('btn-clear').addEventListener('click', () => {
  clearGraph();
  clearValidation();
});

document.getElementById('speed-slider').addEventListener('input', e => {
  document.getElementById('speed-label').textContent = e.target.value + 'x';
});

/* Keyboard shortcuts */
document.addEventListener('keydown', e => {
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') return;
  if (e.code === 'Space') { e.preventDefault(); togglePlay(); }
  if (e.code === 'ArrowRight') { e.preventDefault(); stepForward(); }
  if (e.code === 'ArrowLeft') { e.preventDefault(); stepBackward(); }
  if (e.code === 'KeyR') { e.preventDefault(); resetPlayback(); }
  if (e.key === '+' || e.key === '=') zoomBy(1.2);
  if (e.key === '-' || e.key === '_') zoomBy(1 / 1.2);
  if (e.key === '0') fitView();
});

/* ================================================================
   SECTION 19: SELF-TESTS
================================================================ */

function runSelfTests() {
  const suites = [];

  function suite(name, fn) {
    const cases = [];
    const assert = (condition, msg, detail) => {
      cases.push({ pass: !!condition, name: msg, detail: detail || '' });
    };
    try { fn(assert); } catch(err) { cases.push({ pass: false, name: 'Exception', detail: err.message }); }
    suites.push({ name, cases });
  }

  // Helper: build a test graph
  function makeGraph(directed, nodes, edges) {
    return {
      directed,
      nodes: nodes.map((n, i) => ({ id: i + 1, label: n, x: i * 100, y: 100 })),
      edges: edges.map((e, i) => ({ id: i + 1, from: e[0], to: e[1], weight: e[2] }))
    };
  }

  // ── Dijkstra Tests ──────────────────────────────────────────
  suite('Dijkstra', assert => {
    // Fixture A
    const g = {
      directed: false,
      nodes: [1,2,3,4,5,6].map((id,i) => ({ id, label: 'ABCDEF'[i], x: i*100, y: 100 })),
      edges: [
        { id:1, from:1, to:2, weight:4 },
        { id:2, from:1, to:3, weight:2 },
        { id:3, from:2, to:3, weight:1 },
        { id:4, from:2, to:4, weight:5 },
        { id:5, from:3, to:4, weight:8 },
        { id:6, from:3, to:5, weight:10 },
        { id:7, from:4, to:5, weight:2 },
        { id:8, from:4, to:6, weight:6 },
        { id:9, from:5, to:6, weight:3 },
      ]
    };
    const r = runDijkstra(g, 1, 6);
    assert(r.status === 'ok', 'Fixture A: status ok');
    assert(r.cost === 13, `Fixture A: A→F cost 13 (A→C→B→D→E→F)`, `got ${r.cost}`);
    assert(r.path && r.path[0] === 1 && r.path[r.path.length-1] === 6, 'Fixture A: path starts A ends F');

    // Unreachable
    const g2 = makeGraph(true, ['A','B','C','D'], [[1,2,2],[3,4,1]]);
    const r2 = runDijkstra(g2, 1, 4);
    assert(r2.status === 'unreachable', 'Fixture D: unreachable');

    // Single vertex
    const g3 = { directed: false, nodes: [{id:1, label:'A', x:0, y:0}], edges: [] };
    const r3 = runDijkstra(g3, 1, 1);
    assert(r3.distances[1] === 0, 'Single vertex: dist=0');

    // Zero-weight edges
    const g4 = makeGraph(true, ['A','B'], [[1,2,0]]);
    const r4 = runDijkstra(g4, 1, 2);
    assert(r4.cost === 0, 'Zero-weight edge: cost 0');

    // Source=target
    const r5 = runDijkstra(g, 1, 1);
    assert(r5.cost === 0 || r5.distances[1] === 0, 'Source=target: cost 0');
  });

  // ── Bellman-Ford Tests ────────────────────────────────────
  suite('Bellman-Ford', assert => {
    // Fixture B: negative edge without cycle
    const g = {
      directed: true,
      nodes: [1,2,3,4].map((id,i) => ({ id, label:'ABCD'[i], x:i*100, y:100 })),
      edges: [
        { id:1, from:1, to:2, weight:4 },
        { id:2, from:1, to:3, weight:5 },
        { id:3, from:2, to:3, weight:-2 },
        { id:4, from:3, to:4, weight:3 },
        { id:5, from:2, to:4, weight:6 },
      ]
    };
    const r = runBellmanFord(g, 1, 4);
    assert(r.status === 'ok', 'Fixture B: status ok');
    assert(r.cost === 5, `Fixture B: A→D cost 5`, `got ${r.cost}`);

    // Fixture C: negative cycle
    const gc = {
      directed: true,
      nodes: [1,2,3].map((id,i) => ({ id, label:'ABC'[i], x:i*100, y:100 })),
      edges: [
        { id:1, from:1, to:2, weight:1 },
        { id:2, from:2, to:3, weight:-3 },
        { id:3, from:3, to:1, weight:1 },
      ]
    };
    const rc = runBellmanFord(gc, 1, 2);
    assert(rc.status === 'neg-cycle', 'Fixture C: detects neg-cycle');
    assert(rc.negCycle === true, 'Fixture C: negCycle flag');

    // Fixture D: unreachable
    const gd = makeGraph(true, ['A','B','C','D'], [[1,2,2],[3,4,1]]);
    const rd = runBellmanFord(gd, 1, 4);
    assert(rd.status === 'unreachable', 'Fixture D: unreachable');
  });

  // ── BFS Tests ─────────────────────────────────────────────
  suite('BFS', assert => {
    // Fixture A (hop count)
    const g = {
      directed: false,
      nodes: [1,2,3,4,5,6].map((id,i) => ({ id, label:'ABCDEF'[i], x:i*100, y:100 })),
      edges: [
        { id:1, from:1, to:2, weight:4 },
        { id:2, from:1, to:3, weight:2 },
        { id:3, from:2, to:3, weight:1 },
        { id:4, from:2, to:4, weight:5 },
        { id:5, from:3, to:4, weight:8 },
        { id:6, from:3, to:5, weight:10 },
        { id:7, from:4, to:5, weight:2 },
        { id:8, from:4, to:6, weight:6 },
        { id:9, from:5, to:6, weight:3 },
      ]
    };
    const r = runBFS(g, 1, 6);
    assert(r.status === 'ok', 'Fixture A BFS: ok');
    assert(r.cost === 3, `Fixture A BFS: A→F = 3 hops`, `got ${r.cost}`);

    // BFS ignores weights — path from A to F should be 3 hops
    assert(r.path && r.path[0] === 1 && r.path[r.path.length-1] === 6, 'Path starts/ends correctly');

    // Fixture D: unreachable
    const gd = makeGraph(true, ['A','B','C','D'], [[1,2,2],[3,4,1]]);
    const rd = runBFS(gd, 1, 4);
    assert(rd.status === 'unreachable', 'Fixture D BFS: unreachable');
  });

  // ── Floyd-Warshall Tests ──────────────────────────────────
  suite('Floyd-Warshall', assert => {
    // Fixture B
    const g = {
      directed: true,
      nodes: [1,2,3,4].map((id,i) => ({ id, label:'ABCD'[i], x:i*100, y:100 })),
      edges: [
        { id:1, from:1, to:2, weight:4 },
        { id:2, from:1, to:3, weight:5 },
        { id:3, from:2, to:3, weight:-2 },
        { id:4, from:3, to:4, weight:3 },
        { id:5, from:2, to:4, weight:6 },
      ]
    };
    const r = runFloydWarshall(g);
    assert(r.status === 'ok', 'Fixture B FW: ok');
    const si = r.idx[1], ti = r.idx[4];
    assert(r.matrix[si][ti] === 5, `Fixture B FW: A→D cost 5`, `got ${r.matrix[si][ti]}`);

    // Fixture C: negative cycle detection
    const gc = {
      directed: true,
      nodes: [1,2,3].map((id,i) => ({ id, label:'ABC'[i], x:i*100, y:100 })),
      edges: [
        { id:1, from:1, to:2, weight:1 },
        { id:2, from:2, to:3, weight:-3 },
        { id:3, from:3, to:1, weight:1 },
      ]
    };
    const rc = runFloydWarshall(gc);
    assert(rc.status === 'neg-cycle' || rc.negCycle, 'Fixture C FW: detects neg-cycle');
  });

  // ── A* Tests ──────────────────────────────────────────────
  suite('A*', assert => {
    const g = {
      directed: false,
      nodes: [
        { id:1, label:'S', x:0, y:200 },
        { id:2, label:'A', x:140, y:100 },
        { id:3, label:'B', x:140, y:300 },
        { id:4, label:'C', x:290, y:100 },
        { id:5, label:'T', x:420, y:200 },
      ],
      edges: [
        { id:1, from:1, to:2, weight:1 },
        { id:2, from:1, to:3, weight:4 },
        { id:3, from:2, to:4, weight:2 },
        { id:4, from:3, to:5, weight:5 },
        { id:5, from:4, to:5, weight:1 },
      ]
    };
    const r = runAStar(g, 1, 5, 'zero');
    assert(r.status === 'ok', 'A* h=0: ok');
    assert(r.cost === 4, `A* h=0: S→T cost 4`, `got ${r.cost}`);

    // Compare with Dijkstra
    const d = runDijkstra(g, 1, 5);
    assert(r.cost === d.cost, 'A* h=0 matches Dijkstra');

    // Unreachable
    const g2 = makeGraph(false, ['A','B'], []);
    const r2 = runAStar(g2, 1, 2, 'zero');
    assert(r2.status === 'unreachable', 'A*: unreachable detected');
  });

  // ── DAG Shortest Path Tests ───────────────────────────────
  suite('DAG Shortest Path', assert => {
    // Fixture F
    const g = {
      directed: true,
      nodes: [1,2,3,4].map((id,i) => ({ id, label:'ABCD'[i], x:i*100, y:100 })),
      edges: [
        { id:1, from:1, to:2, weight:3 },
        { id:2, from:1, to:3, weight:6 },
        { id:3, from:2, to:3, weight:-2 },
        { id:4, from:2, to:4, weight:4 },
        { id:5, from:3, to:4, weight:2 },
      ]
    };
    const r = runDAG(g, 1, 4);
    assert(r.status === 'ok', 'Fixture F DAG: ok');
    assert(r.cost === 3, `Fixture F DAG: A→D cost 3`, `got ${r.cost}`);

    // Fixture G: invalid DAG (has cycle)
    const gi = {
      directed: true,
      nodes: [1,2,3].map((id,i) => ({ id, label:'ABC'[i], x:i*100, y:100 })),
      edges: [
        { id:1, from:1, to:2, weight:2 },
        { id:2, from:2, to:3, weight:3 },
        { id:3, from:3, to:1, weight:1 },
      ]
    };
    const ri = runDAG(gi, 1, 2);
    assert(ri.status === 'error', 'Fixture G: cycle detected');

    // Undirected should fail
    const gu = { ...g, directed: false };
    const ru = runDAG(gu, 1, 4);
    assert(ru.status === 'error', 'DAG: rejects undirected');
  });

  // ── 0-1 BFS Tests ─────────────────────────────────────────
  suite('0-1 BFS', assert => {
    // Fixture E
    const g = {
      directed: true,
      nodes: [1,2,3,4].map((id,i) => ({ id, label:'ABCD'[i], x:i*100, y:100 })),
      edges: [
        { id:1, from:1, to:2, weight:1 },
        { id:2, from:1, to:3, weight:0 },
        { id:3, from:3, to:2, weight:0 },
        { id:4, from:2, to:4, weight:1 },
        { id:5, from:3, to:4, weight:1 },
      ]
    };
    const r = run01BFS(g, 1, 2);
    assert(r.status === 'ok', 'Fixture E 0-1BFS: ok');
    assert(r.cost === 0, `Fixture E 0-1BFS: A→B cost 0`, `got ${r.cost}`);
    assert(r.path && r.path.includes(3), 'Fixture E: path goes through C');

    // Unreachable
    const g2 = makeGraph(true, ['A','B','C'], [[1,2,1]]);
    const r2 = run01BFS(g2, 1, 3);
    assert(r2.status === 'unreachable', '0-1 BFS: unreachable');
  });

  // ── Path Reconstruction Tests ─────────────────────────────
  suite('Path Reconstruction', assert => {
    // Valid path
    const prev = { 1: null, 2: 1, 3: 2 };
    const p = reconstructPath(prev, 1, 3);
    assert(p && p[0] === 1 && p[p.length-1] === 3, 'Reconstruct: valid path');

    // Unreachable (no predecessor)
    const prev2 = { 1: null, 2: null };
    const p2 = reconstructPath(prev2, 1, 2);
    assert(p2 === null, 'Reconstruct: unreachable returns null');
  });

  // ── Topological Sort Tests ────────────────────────────────
  suite('Topological Sort', assert => {
    const dagG = {
      directed: true,
      nodes: [1,2,3,4].map((id,i) => ({id, label:'ABCD'[i], x:0, y:0})),
      edges: [
        {id:1,from:1,to:2,weight:1},
        {id:2,from:1,to:3,weight:1},
        {id:3,from:2,to:4,weight:1},
        {id:4,from:3,to:4,weight:1},
      ]
    };
    const {order, isCyclic} = topologicalSort(dagG);
    assert(!isCyclic, 'Topo: DAG not cyclic');
    assert(order.indexOf(1) < order.indexOf(2), 'Topo: A before B');
    assert(order.indexOf(2) < order.indexOf(4), 'Topo: B before D');

    // Cyclic graph
    const cyclicG = {
      directed: true,
      nodes: [1,2,3].map((id,i) => ({id, label:'ABC'[i], x:0, y:0})),
      edges: [{id:1,from:1,to:2,weight:1},{id:2,from:2,to:3,weight:1},{id:3,from:3,to:1,weight:1}]
    };
    const {isCyclic: c2} = topologicalSort(cyclicG);
    assert(c2, 'Topo: detects cycle');
  });

  // ── Edge Cases ────────────────────────────────────────────
  suite('Edge Cases', assert => {
    // Empty graph BFS
    const emptyG = { directed: false, nodes: [], edges: [] };
    try {
      const r = runBFS(emptyG, null, null);
      assert(true, 'Empty graph: no crash');
    } catch(e) { assert(false, 'Empty graph: crashed', e.message); }

    // Graph with only isolated vertices
    const isoG = { directed: false, nodes: [{id:1,label:'A',x:0,y:0},{id:2,label:'B',x:100,y:0}], edges: [] };
    const r2 = runBFS(isoG, 1, 2);
    assert(r2.status === 'unreachable', 'Isolated vertices: unreachable');

    // Equal-cost paths (Dijkstra)
    const eqG = {
      directed: false,
      nodes: [{id:1,label:'A',x:0,y:0},{id:2,label:'B',x:100,y:0},{id:3,label:'C',x:100,y:100},{id:4,label:'D',x:200,y:50}],
      edges: [{id:1,from:1,to:2,weight:5},{id:2,from:1,to:3,weight:3},{id:3,from:2,to:4,weight:3},{id:4,from:3,to:4,weight:5}]
    };
    const r3 = runDijkstra(eqG, 1, 4);
    assert(r3.cost === 8, `Equal-cost paths: cost 8`, `got ${r3.cost}`);
  });

  return suites;
}

function displayTestResults(suites) {
  let totalPass = 0, totalFail = 0;
  let html = '';

  for (const suite of suites) {
    const pass = suite.cases.filter(c => c.pass).length;
    const fail = suite.cases.filter(c => !c.pass).length;
    totalPass += pass;
    totalFail += fail;

    html += `<div class="test-group">
      <div class="test-group-title">${escapeHtml(suite.name)} — ${pass}/${suite.cases.length} passed</div>`;
    for (const c of suite.cases) {
      html += `<div class="test-case ${c.pass ? 'test-pass' : 'test-fail'}">
        <span class="test-icon">${c.pass ? '✓' : '✗'}</span>
        <div><div class="test-name">${escapeHtml(c.name)}</div>${c.detail ? `<div class="test-detail">${escapeHtml(c.detail)}</div>` : ''}</div>
      </div>`;
    }
    html += '</div>';
  }

  const allPass = totalFail === 0;
  const summaryHtml = `<div class="test-summary ${allPass ? 'all-pass' : 'has-fail'}">
    ${allPass ? '✓ All' : `${totalFail} failing,`} ${totalPass} of ${totalPass + totalFail} tests passed.
  </div>`;

  document.getElementById('test-results-body').innerHTML = summaryHtml + html;
  openModal('modal-tests');
}

document.getElementById('btn-run-tests').addEventListener('click', () => {
  const suites = runSelfTests();
  displayTestResults(suites);
});

/* ================================================================
   SECTION 20: MASTER UPDATE FUNCTION
================================================================ */

function updateAll() {
  populateSelectors();
  renderGraph();
  updateGraphStats();
  checkAndShowValidation();
}

/* ================================================================
   SECTION 21: INITIALIZATION
================================================================ */

/* ── One-click shortest path: picks the best algorithm for the graph ── */
function chooseBestAlgorithm() {
  const ew = e => (isWeighted() ? e.weight : 1);
  const edges = graph.edges;
  if (edges.every(e => ew(e) === 1)) return 'bfs';
  if (edges.some(e => ew(e) < 0)) {
    return graph.directed && !topologicalSort(graph).isCyclic ? 'dag' : 'bellman-ford';
  }
  if (edges.every(e => ew(e) === 0 || ew(e) === 1)) return '01bfs';
  return 'dijkstra';
}

function findShortestPath() {
  if (!graph.nodes.length) { showValidation('Graph is empty. Add vertices and edges first.', 'error'); return; }
  if (!graph.source || !graph.target) {
    showValidation('Pick a Source and a Target (dropdowns, or Shift+click / Alt+click a node in Select mode).', 'error');
    return;
  }
  const algo = chooseBestAlgorithm();
  document.getElementById('algo-select').value = algo;
  updateAlgoUI();
  invalidateResults();
  runAlgorithm();
  if (!execResult) return;
  currentEventIndex = execResult.events.length - 1;     // jump straight to the final answer
  applyEvent(currentEventIndex);
  updatePlaybackUI();
  updateStepCounter();
  showValidation(`Auto-selected ${ALGO_META[algo].name} as the best fit for this graph. Use Reset + Play to watch it step by step.`, 'info');
}
document.getElementById('btn-find').addEventListener('click', findShortestPath);

function init() {
  resetView();
  updateAlgoUI();
  document.getElementById('chk-directed').checked = graph.directed;
  document.getElementById('chk-weighted').checked = true;
  updateAll();

  // Load default example
  loadExample('nonneg');
  fitView();
}

init();