
from pathlib import Path

# Project folder: the folder containing this script
PROJECT_DIR = Path(__file__).resolve().parent
OUTPUT_FILE = PROJECT_DIR / "pathpilot_complete_code.txt"

# Source files and other useful project files to include
INCLUDE_EXTENSIONS = {
    ".html",
    ".css",
    ".js",
    ".json",
    ".md",
    ".py",
    ".txt",
}

# Folders and files to ignore
IGNORE_DIRS = {
    ".git",
    "node_modules",
    "__pycache__",
    ".venv",
    "venv",
    "dist",
    "build",
}

IGNORE_FILES = {
    OUTPUT_FILE.name,
    "package_code.py",
    ".DS_Store",
}

def should_include(file_path):
    if file_path.name in IGNORE_FILES:
        return False

    if any(part in IGNORE_DIRS for part in file_path.parts):
        return False

    # Skip hidden files, which may contain secrets
    if any(part.startswith(".") for part in file_path.relative_to(PROJECT_DIR).parts):
        return False

    return file_path.suffix.lower() in INCLUDE_EXTENSIONS


def main():
    files = sorted(
        file for file in PROJECT_DIR.rglob("*")
        if file.is_file() and should_include(file)
    )

    with OUTPUT_FILE.open("w", encoding="utf-8") as output:
        output.write("PATHPILOT — COMPLETE PROJECT SOURCE\n")
        output.write("=" * 80 + "\n")
        output.write(f"Project directory: {PROJECT_DIR.name}\n")
        output.write(f"Files included: {len(files)}\n")
        output.write("=" * 80 + "\n\n")

        for file_path in files:
            relative_path = file_path.relative_to(PROJECT_DIR)

            output.write("\n\n")
            output.write("#" * 80 + "\n")
            output.write(f"FILE: {relative_path.as_posix()}\n")
            output.write("#" * 80 + "\n\n")

            try:
                content = file_path.read_text(encoding="utf-8")
                output.write(content)
            except (UnicodeDecodeError, OSError) as error:
                output.write(f"[Could not read file: {error}]\n")

            output.write("\n\n" + "=" * 80 + "\n")

    print(f"Done! Packaged {len(files)} files.")
    print(f"Output: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
