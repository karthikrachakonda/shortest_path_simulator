# PathPilot 2.0 — Interactive Shortest Path Algorithm Simulator

A complete, browser-native educational tool for visualizing and exploring seven classic shortest-path algorithms. No installation, no build step, no backend.

---

## How to Run

1. Open `index.html` in any modern browser (Chrome, Firefox, Edge, Safari).
2. No server, npm install, or build step is required.
3. An internet connection is only needed to load the Google Fonts stylesheet; the application functions fully offline without it.

---

## Project Structure

```
PathPilot/
├── index.html   — Application layout and HTML structure
├── style.css    — Complete dark-theme stylesheet (design tokens + components)
├── app.js       — All algorithms, graph model, UI logic, playback engine, and self-tests
└── README.md    — This file
```

---

## Graph Editor

| Action | How |
|--------|-----|
| **Add vertex** | Select "Add Node" tool → click the canvas |
| **Move vertex** | Select "Select" tool → drag a node |
| **Add edge** | Select "Add Edge" tool → click node 1, then node 2 |
| **Edit edge weight** | Double-click an edge → change weight in popup |
| **Delete vertex or edge** | Select "Delete" tool → click target |
| **Clear graph** | Click the "Clear Graph" button |
| **Fit view** | Click "Fit View" to re-center all nodes |
| **Set source/target** | Use the Source and Target dropdowns in the left panel |

---

## Import / Export

- **Export**: Click the "Export" button in the header. Downloads `pathpilot-graph.json`.
- **Import**: Click the "Import" button → select a `.json` file.

JSON format:
```json
{
  "directed": false,
  "source": 1,
  "target": 6,
  "nodes": [
    { "id": 1, "label": "A", "x": 100, "y": 200 },
    ...
  ],
  "edges": [
    { "id": 1, "from": 1, "to": 2, "weight": 4 },
    ...
  ]
}
```

The importer validates: node IDs are unique, edge endpoints exist, and all weights are finite numbers.

---

## Algorithms

### 1. Dijkstra's Algorithm
- **Purpose**: Single-source shortest paths in non-negative-weight graphs.
- **Graph type**: Directed or undirected.
- **Weight constraint**: All weights ≥ 0. Rejects negative weights.
- **Time complexity**: O(V² + E) with array-based min selection.
- **Space complexity**: O(V).
- **Requires**: Source vertex.
- **Optional**: Target vertex (early termination when target is finalized).

### 2. Bellman-Ford Algorithm
- **Purpose**: Single-source shortest paths with negative edge support.
- **Graph type**: Directed or undirected.
- **Weight constraint**: Any finite weight, including negatives.
- **Negative cycle detection**: Yes. Reports reachable negative cycles.
- **Time complexity**: O(V × E).
- **Space complexity**: O(V).
- **Requires**: Source vertex.
- **Note**: An undirected negative edge creates a negative cycle automatically.

### 3. Breadth-First Search (BFS)
- **Purpose**: Minimum-hop path in an unweighted graph.
- **Graph type**: Directed or undirected.
- **Weight constraint**: Weights are ignored. Results are hop counts.
- **Time complexity**: O(V + E).
- **Space complexity**: O(V).
- **Requires**: Source vertex.

### 4. Floyd-Warshall Algorithm
- **Purpose**: All-pairs shortest paths.
- **Graph type**: Directed or undirected.
- **Weight constraint**: Allows negatives.
- **Negative cycle detection**: Yes. Detected via D[i][i] < 0 after completion.
- **Time complexity**: O(V³).
- **Space complexity**: O(V²).
- **Does not require** source or target (all-pairs mode).
- **UI**: Shows the full distance matrix. Click "Show" to highlight a specific route.

### 5. A* Search
- **Purpose**: Heuristic-guided shortest path to a specific target.
- **Graph type**: Directed or undirected.
- **Weight constraint**: Non-negative weights only (baseline implementation).
- **Heuristics**: Zero (equivalent to Dijkstra), Euclidean distance, Manhattan distance.
- **Time complexity**: O((V+E) log V) with admissible heuristic; worst-case exponential for general search.
- **Space complexity**: O(V).
- **Requires**: Source and target vertices.

### 6. DAG Shortest Path
- **Purpose**: Single-source shortest paths in a directed acyclic graph.
- **Graph type**: Directed only.
- **Weight constraint**: Allows negatives.
- **Cycle detection**: Yes. Uses Kahn's topological sort to detect cycles and reject cyclic graphs.
- **Time complexity**: O(V + E).
- **Space complexity**: O(V).
- **Requires**: Source vertex; directed mode enabled.

### 7. 0–1 BFS
- **Purpose**: Shortest paths when every edge weight is 0 or 1.
- **Graph type**: Directed or undirected.
- **Weight constraint**: All weights must be exactly 0 or 1. Rejects other values.
- **Time complexity**: O(V + E).
- **Space complexity**: O(V).
- **Requires**: Source vertex.
- **Uses a deque**: 0-weight neighbors pushed to front, 1-weight to back.

---

## Example Graphs (Predefined Fixtures)

| Button | Description | Algorithms |
|--------|-------------|------------|
| **A: Non-neg** | 6-node undirected, non-negative weights. A→F = 13 (weighted), 3 hops (BFS). | Dijkstra, BFS, Floyd-Warshall |
| **B: Neg-Edge** | 4-node directed, one negative edge (B→C = −2). A→D = 5. | Bellman-Ford, DAG, Floyd-Warshall |
| **C: Neg-Cycle** | 3-node directed cycle with sum −1. A→B→C→A total = −1. | Bellman-Ford, Floyd-Warshall |
| **D: Unreach** | Disconnected directed graph. A→D is unreachable. | All algorithms |
| **E: 0-1 BFS** | 4-node directed. A→B shortest = 0 hops via A→C→B. | 0-1 BFS |
| **F: DAG** | 4-node directed acyclic. A→D = 3 via A→B→C→D. | DAG Shortest Path |
| **G: Bad DAG** | 3-node directed cycle — must be rejected. | DAG Shortest Path (error case) |
| **H: A* Star** | 5-node, S→T = 4. A* with h=0 matches Dijkstra. | A* Search |

---

## Test Fixtures and Expected Results

| Fixture | Algorithm | Source | Target | Expected Distance | Notes |
|---------|-----------|--------|--------|-------------------|-------|
| A | Dijkstra | A | F | 13 | Path: A→C(2)→B(1)→D(5)→E(2)→F(3) = 13 |
| A | BFS | A | F | 3 hops | Ignores weights |
| B | Bellman-Ford | A | D | 5 | Path: A→B→C→D |
| B | DAG | A | D | 3 | DAG example |
| C | Bellman-Ford | A | — | neg-cycle | Negative cycle detected |
| D | Any | A | D | unreachable | No path exists |
| E | 0-1 BFS | A | B | 0 | Path: A→C→B |
| F | DAG | A | D | 3 | Path: A→B→C→D |
| G | DAG | A | B | error | Graph has cycle |
| H | A* | S | T | 4 | Path: S→A→C→T |

---

## Self-Tests

Click **Self-Tests** in the header to run the built-in JavaScript test suite.

Tests cover:
- Fixture A–H expected results for all 7 algorithms.
- Single vertex, empty graph, and isolated vertex edge cases.
- Negative cycle detection (Bellman-Ford and Floyd-Warshall).
- Cycle rejection (DAG algorithm).
- Unreachable destination for all algorithms.
- Zero-weight edges.
- Equal-cost paths.
- Path reconstruction correctness.
- Topological sort (valid DAG and cyclic graph).
- A* h=0 matches Dijkstra output.

All tests run without requiring any external library.

---

## Known Limitations

- **Graph size**: The interactive demo limits vertices to 20. Floyd-Warshall may generate many events for larger graphs.
- **A* heuristic**: Geometric heuristics (Euclidean, Manhattan) are only admissible when edge weights are proportional to canvas pixel distances. For arbitrary weights, use the Zero heuristic.
- **Parallel edges**: Not supported. Adding an edge between nodes that already have an edge is prevented.
- **Self-loops**: Not supported.
- **Negative edges in undirected graphs**: Bellman-Ford will correctly detect these as negative cycles.
- **FW on large graphs**: The distance matrix grows as V², which can affect rendering performance.
- **Playback**: Events are precomputed before playback. Editing the graph invalidates the current execution.

---

## Faculty Demonstration Script

1. **Load "A: Non-neg"** → Select Dijkstra → Run → Step through edge relaxation. Explain greedy min-distance selection.
2. **Run BFS on same graph** → Compare: BFS result = 3 hops, Dijkstra = 13 weighted cost. Emphasize that BFS ignores weights.
3. **Load "B: Neg-Edge"** → Select Bellman-Ford → Run → Show multiple passes, explain early exit.
4. **Load "C: Neg-Cycle"** → Run Bellman-Ford → Show negative cycle detection.
5. **Load "A: Non-neg"** → Run Floyd-Warshall → Explore the all-pairs matrix. Click "Show" to trace any pair's route.
6. **Load "H: A* Star"** → Select A* → Set heuristic to Zero → Run → Show g(n), h(n), f(n) columns.
7. **Load "F: DAG"** → Select DAG Shortest Path → Run → Show topological ordering panel.
8. **Load "E: 0-1 BFS"** → Run 0-1 BFS → Show deque contents, highlight front vs back insertions.
9. **Load "G: Bad DAG"** → Run DAG → Show cycle rejection error.
10. **Click Self-Tests** → Walk through the test results panel.

---

## Technology Stack

- HTML5 + CSS3 + Vanilla JavaScript (ES6+)
- SVG for all graph rendering
- Browser-native File API for import/export
- Google Fonts (Inter, JetBrains Mono) via CDN — graceful degradation without internet
- No frameworks, no build tools, no package installation required

## What's new in this version
- Black & yellow theme.
- Zoom (+/−, mouse wheel, 1:1, Fit, keys `+` `-` `0`) and pan (drag empty canvas, or Shift/middle-drag).
- **Find Shortest Path** button: auto-picks BFS / 0-1 BFS / Dijkstra / DAG / Bellman-Ford and shows the path and cost instantly.
- Shift+click a node = Source, Alt+click = Target (Select tool).
- Many bug fixes (see the chat summary).